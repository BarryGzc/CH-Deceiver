import sys, multiprocessing

sys.path.append('/data/gzc/works/similarity_shop/utils')
from morphology import *
from phonetics import *
from semantics import *
import pickle, time, random, argparse
import numpy as np


def gen(keywords_list, mode='all'):
    if mode == 'all' or mode == 'morphology' or mode == 'all2':
        # !!!!!!!!!!!!!!!!!!!!!!!! Morphology
        char_radical = CharRadical()
        chai_keywords = []
        for keyword in keywords_list:
            chai_res = char_radical(keyword)
            keyword_all = keyword
            chai_keywords_one = []
            for i in chai_res:
                keyword_one = keyword
                if i.get('structure') == '左右结构' or i.get('structure') == '左中右结构':
                    if len(i.get('stroke_order')) < 4:
                        keyword_one = keyword_one.replace(i.get('char'), i.get('stroke_order'))
                        keyword_all = keyword_all.replace(i.get('char'), i.get('stroke_order'))
                        chai_keywords_one.append(keyword_one)
            chai_keywords_one.append(keyword_all)
            chai_keywords_one = sorted(set(chai_keywords_one), key=chai_keywords_one.index)  # 列表有序去重

            chai_keywords.append(chai_keywords_one)
            # print(chai_kewords)关键词的每个字都拆一遍，再加上全拆

        similar_words = []
        for word in keywords_list:
            similar_words_one = []
            chars = list(word)
            newchars_all = list(word)
            for i, char in enumerate(chars):
                newchars_all[i] = getbest_siamese(char, 1)  # most similar char
                newchars_one = chars[:]
                newchars_one[i] = getbest_siamese(char, 1)  # most similar char
                similar_words_one.append(''.join(newchars_one))
            similar_words_one.append(''.join(newchars_all))
            similar_words_one = sorted(set(similar_words_one), key=similar_words_one.index)  # 列表有序去重

            similar_words.append(similar_words_one)

        # 合并两个list
        examples_morphology = []
        assert len(chai_keywords) == len(chai_keywords), "Bug in morphology"
        for i in range(len(chai_keywords)):
            examples_morphology.append(tuple(chai_keywords[i] + similar_words[i]))

    if mode == 'all' or mode == 'phonetics' or mode == 'all2':
        # !!!!!!!!!!!!!!!!!!!!!!!!phonetics
        pinyin = Pinyin()
        pinyin_all = []
        pinyin_initial = []
        for keyword in keywords_list:
            pinyin_all_tmp = pinyin(keyword)
            pinyin_all.append(''.join(pinyin_all_tmp))
            pinyin_initial.append(''.join([x[0] for x in pinyin_all_tmp]))
        # print(pinyin_all)
        # print(pinyin_initial)

        homophone_substitution = HomophoneSubstitution()
        homophone = homophone_substitution(keywords_list)
        # print(homophone)

        examples_phonetics = list(zip(pinyin_all, pinyin_initial, homophone))
        # print('phonetics：{}'.format(examples_phonetics))

    if mode == 'all' or mode == 'semantics':
        # !!!!!!!!!!!!!!!!!!!!!!!! semantics，5个
        examples_semantics = []
        for word in keywords_list:
            syn = synonyms_zw(word, size=5)
            # syn = cilin_word_syn(word, size=2)
            if not syn:
                syn = ('', '', '')
            examples_semantics.append(syn)
        # print('semantics：{}'.format(examples_semantics))

    if mode == 'all' or mode == 'simple':
        # !!!!!!!!!!!!!!!!!!!!!!!! simple
        examples_basic = []
        for word in keywords_list:
            if len(word) == 1:  # 单字，加1字
                basic_changed = [word + word]
            elif not word.strip(word[0]):  # 叠词如'个个'，删1字
                basic_changed = [word.replace(word[0], '', 1)]
            elif len(word) == 2:  # 双字词，无叠
                basic_changed = []
                basic_shu = list(word)
                random.shuffle(basic_shu)
                while ''.join(basic_shu) == word:
                    basic_shu = list(word)
                    random.shuffle(basic_shu)
                basic_changed.append(''.join(basic_shu))
                for i in range(len(word)):
                    basic_del = list(word)
                    basic_del.pop(i)
                    basic_changed.append(''.join(basic_del))
            elif len(word) > 2:  # 多字词，无叠
                basic_changed = []
                while len(basic_changed) < len(word):
                    basic_shu = list(word)
                    random.shuffle(basic_shu)
                    if not ''.join(basic_shu) in basic_changed:
                        basic_changed.append(''.join(basic_shu))
                for i in range(len(word)):
                    basic_del = list(word)
                    basic_del.pop(i)
                    basic_changed.append(''.join(basic_del))
            examples_basic.append(tuple(basic_changed))

    # !!!!!!!!!!!!!!!!!!!!!!!! 合并，生成最后结果
    if mode == 'all':
        if len(examples_phonetics) == len(examples_morphology) == len(examples_semantics):
            examples_all = [examples_morphology[i] + examples_phonetics[i] + examples_semantics[i] + examples_basic[i]
                            for i in range(len(examples_phonetics))]
        else:
            raise Exception('Bug in Generating')
        return examples_all
    elif mode == 'morphology':
        return examples_morphology
    elif mode == 'phonetics':
        return examples_phonetics
    elif mode == 'semantics':
        return examples_semantics
    elif mode == 'simple':
        return examples_basic
    elif mode == 'all2':
        if len(examples_phonetics) == len(examples_morphology):
            examples_all = [examples_morphology[i] + examples_phonetics[i] for i in range(len(examples_phonetics))]
        else:
            raise Exception('Bug in Generating')
        return examples_all


parser = argparse.ArgumentParser(description='Configuration')
parser.add_argument('--model', default='TextCNN', type=str, required=True,
                    help='Bert,TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer')
parser.add_argument('--mode', default='all', type=str, help='all,morphology,phonetics,semantics,simple')
parser.add_argument('--word', default=False, type=bool, help='True for word, False for char')
args = parser.parse_args()

if __name__ == '__main__':

    # model_name = 'Bert'  # 八选一：Bert,TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer
    # mode = 'all'  # 四选一：all,morphology,phonetics,semantics,simple,all2
    model_name = args.model
    mode = args.mode

    keywords_file = '/data/gzc/works/similarity_shop/result/%s__keywords.csv' % model_name

    input_key_df = pd.read_csv(keywords_file)
    #############keyword以text为column时
    input_key_dic = input_key_df.to_dict(orient='list')
    for i in input_key_dic.values():
        while np.nan in i:
            i.remove(np.nan)
    texts_list = list(input_key_dic.keys())
    keywords_list = list(input_key_dic.values())

    all_time_start = time.time()

    res_gen = []  # 所有句子的所有关键词的变体
    for i, keywords in enumerate(keywords_list):
        time_start = time.time()
        res = gen(keywords, mode)  # 一个句子的所有关键词的变体

        res_gen.append(res)
        time_end = time.time()
        print('第{}个文本耗时:{}'.format(i + 1, time_end - time_start))

    all_time_end = time.time()
    print('#########################################')
    print('网络{},模式{}下，共{}个文本，总耗时:{}，即{}'.format(model_name, mode, i + 1, round(all_time_end - all_time_start, 4),
                                                time.strftime("%H:%M:%S", time.gmtime(all_time_end - all_time_start))))

    res_dict = dict(zip(texts_list, res_gen))
    res_df = pd.DataFrame(dict([(k, pd.Series(v)) for k, v in res_dict.items()]))  # 解决字典值元素长度不对齐的问题
    res_df.to_csv('/data/gzc/works/similarity_shop/result/%s__%s__generated.csv' % (model_name, mode), index=0)
