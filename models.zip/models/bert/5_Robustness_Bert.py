from my_classifier import batch_predicts,predicts,comparison_getacc
import pandas as pd

if __name__ == '__main__':
    base_text=pd.read_csv('/data/gzc/works/similarity_shop/data/texts_2000_shop.csv')

    model_name='Bert'
    corrected_df=pd.read_csv('/data/gzc/works/similarity_shop/result_defense/Bert__corrected.csv')
    text_before=corrected_df['Text_before'].to_frame()
    text_after=corrected_df['Text_after'].to_frame()

    text_before.rename(columns={'Text_before': 'Text'}, inplace=True)
    text_after.rename(columns={'Text_after': 'Text'}, inplace=True)

    text_before_pred = predicts(text_before)
    text_after_pred = predicts(text_after)

    before_acc = comparison_getacc(base_text, text_before_pred)
    after_acc = comparison_getacc(base_text, text_after_pred)
    
    print('### {} , Before acc:{}'.format(model_name,before_acc))
    print('### {} , After acc:{}'.format(model_name,after_acc))




    #保存于./tmp/
