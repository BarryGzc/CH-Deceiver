from my_classifier import batch_predicts, predicts, comparison_getacc
import pandas as pd

if __name__ == '__main__':

    dataset_name = 'shop'
    model_name = 'Bert'
    attack_list = ['Genetic', 'PWWS', 'TextBugger', 'SememePSO']

    base_text = pd.read_csv('/data/gzc/works/similarity_{}/data/texts_2000_{}.csv'.format(dataset_name, dataset_name))

    for attacker_name in attack_list:
        texts_df = pd.read_csv(
            '/data/gzc/works/similarity_backup/openattack/res_{}/{}_to_{}_result.csv'.format(dataset_name,
                                                                                             attacker_name,
                                                                                             model_name))
        predicts_result = predicts(texts_df)
        acc = comparison_getacc(base_text, predicts_result)
        print('########### {}_to_{} on {}2000，样本测试准确率：{}'.format(attacker_name, model_name, dataset_name, acc))
