import pandas as pd
from my_classifier import predicts, comparison_getacc
import sys, argparse

parser = argparse.ArgumentParser(description='Configuration')
parser.add_argument('--model', default='TextCNN', type=str, required=True,
                    help='TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer')
parser.add_argument('--mode', default='all', type=str, help='all,morphology,phonetics,semantics,simple')
parser.add_argument('--word', default=False, type=bool, help='True for word, False for char')
parser.add_argument('--data', default=False, type=str, help='Original Text')
args = parser.parse_args()
while len(sys.argv) > 1:
    sys.argv.pop()

if __name__ == '__main__':

    model_name = args.model
    mode = args.mode
    original_data_file = args.data

    base_text = pd.read_csv(original_data_file)
    res_df = pd.read_csv('/data/gzc/works/similarity_shop/result/%s__%s__FinalRes.csv' % (model_name, mode))

    ############################################## 有效生成率
    res_label = res_df["Result"].value_counts()
    success_rate = res_label['Succeed'] / res_label.sum()

    ############################################## 攻击前的acc
    pred_df = predicts(base_text)
    acc_before = comparison_getacc(base_text, pred_df)
    ############################################## 攻击后的acc
    for i in res_df.Text[res_df.Result == 'Succeed'].index:
        res_df.at[i, 'Text'] = res_df.at[i, 'Example']
    attack_df = res_df['Text'].to_frame()
    attack_df.to_csv('/data/gzc/works/similarity_shop/result/%s__%s__NewExample.csv' % (model_name, mode), index=False)
    pred_df = predicts(attack_df)
    acc_after = comparison_getacc(base_text, pred_df)

    ############################################## 平均扰动
    average_perturbation = res_df['Rate'].mean()

    print("########################## Success Rate ##########################")
    print("Success Rate: {}".format(round(success_rate, 4)))
    print("########################## Effectiveness ##########################")
    print("Predict-Accuracy-before:{}".format(round(acc_before, 4)))
    print("Predict-Accuracy-after: {}".format(round(acc_after, 4)))
    print("########################## Perturbation ##########################")
    print("Predict-Accuracy: {}".format(round(average_perturbation, 4)))
