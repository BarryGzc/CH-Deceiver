import numpy as np
import pandas as pd
from my_classifier import batch_predicts, predicts, comparison_getacc

# from utils import build_dataset, build_iterator, get_time_dif

UNK, PAD = '<UNK>', '<PAD>'

if __name__ == '__main__':
    ###TextCNN, TextRNN, TextRCNN, TextRNN_Att, DPCNN, Transformer, FastText
    # Simulator = 'Bert'  # 取样本，攻击B
    # Victim = 'Bert'  # 被A样本攻击
    mode = 'all'
    ################################################ 原标签
    base_texts = '/data/gzc/works/similarity_shop/data/texts_2000_shop.csv'
    base_label = pd.read_csv(base_texts)

    # simulator_list = ['TextCNN', 'TextRNN', 'TextRCNN', 'TextRNN_Att', 'DPCNN', 'Transformer', 'FastText']
    Simulator = 'TextCNN'
    Victim = 'Bert'

    ################################################ 测试Simulator样本
    Examples_from_Simulator_df = pd.read_csv(
        '/data/gzc/works/similarity_shop/result/%s__%s__NewExample.csv' % (Simulator, mode))
    transfer_result = predicts(Examples_from_Simulator_df)
    tranfer_acc = comparison_getacc(base_label, transfer_result)

    print('########### {} to {}，迁移后acc：{}'.format(Simulator, Victim, tranfer_acc))
