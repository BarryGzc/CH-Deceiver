from my_classifier import predicts
from LAC import LAC
import jieba, re, time,argparse,sys
import pandas as pd


def key(text, ratio):
    # text_token = re.sub("[\s+\.\!\/_,$%^*(+\"\'；：:“”．]+|[+——！，。？?、~@#￥%……&*（）]+", "", text)
    text_token = re.sub('[^\u4e00-\u9fa5]+', '', text)

    ###########jieba分词
    tokens = jieba.lcut(text_token, cut_all=False)
    ###########百度分词
    # lac = LAC(mode='seg')
    # tokens = lac.run(text_token)

    texts_candidate_set = [text]
    for token in tokens:
        texts_candidate_set.append(text.replace(token, '', 1))

    texts_candidate_df = pd.DataFrame(texts_candidate_set, columns=['Examples'])
    res_dic = predicts(texts_candidate_df)
    
    global query_time
    query_time = query_time + texts_candidate_df.shape[0]

    tokens.insert(0, 'None')
    token_candidate_df = pd.DataFrame(tokens, columns=['Tokens'])
    candidate_df = pd.concat([res_dic, token_candidate_df], axis=1)

    conf = []
    for i in range(len(candidate_df)):
        if candidate_df.at[i, 'Label'] == candidate_df.at[0, 'Label']:
            confidence_diff = abs(candidate_df.at[i, 'Confidence'] - candidate_df.at[0, 'Confidence'])
        else:
            confidence_diff = abs(candidate_df.at[i, 'Confidence'] + candidate_df.at[0, 'Confidence']) - 1
        conf.append(confidence_diff)
    conf_diff = pd.DataFrame(conf, columns=['Confidence_diff'])
    res_df = pd.concat([candidate_df, conf_diff], axis=1)

    res_df.sort_values(by=['Confidence_diff'], inplace=True, ascending=False)

    # res_df.to_csv('/data/gzc/works/similarity_shop/models/bert/tmp/all_diff.csv')

    keywords_all = res_df['Tokens'].tolist()
    keywords_all2 = keywords_all[0:int(ratio * len(tokens)) + 1]
    keywords_final = sorted(set(keywords_all2), key=keywords_all2.index)  # 去重

    return keywords_final


def file_key(file, ratio=0.5):
    # 默认取前0.5的关键词

    file_pd = pd.read_csv(file)
    texts = file_pd['Text'].to_list()

    res = []
    for text in texts:
        text2keywords = key(text, ratio)
        res.append(text2keywords)

    res_dict = dict(zip(texts, res))
    # res_df=pd.DataFrame.from_dict(res_dict, orient='index')
    res_df = pd.DataFrame(dict([(k, pd.Series(v)) for k, v in res_dict.items()]))  # 解决字典值元素长度不对齐的问题

    return res_df





parser = argparse.ArgumentParser(description='Configuration')
parser.add_argument('--model', default='TextCNN', type=str, required=True,
                    help='Bert,TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer')
parser.add_argument('--word', default=False, type=bool, help='True for word, False for char')
parser.add_argument('--data', default=False, type=str, help='Original Text_path')
args = parser.parse_args()

while len(sys.argv) > 1:
	sys.argv.pop()

if __name__ == '__main__':
    global query_time
    query_time = 0

    # model_name = 'TextCNN'  # 8选1：Bert,TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer
    model_name = args.model
    original_data_file = args.data


    base_text = original_data_file
    all_time_start = time.time()
    keywords = file_key(base_text, 0.5)  # 默认取前0.5的关键词
    all_time_end = time.time()
    print('#########################################')
    print('共{}个文本，总耗时:{}，即 {}'.format(keywords.shape[1], all_time_end - all_time_start,
                                      time.strftime("%H:%M:%S", time.gmtime(all_time_end - all_time_start))))

    keywords.to_csv('/data/gzc/works/similarity_shop/result/Bert__keywords.csv', index=0)

    with open('/data/gzc/works/similarity_shop/Record_FinaRes.txt', 'a') as f:
        out = '############模型：{}, keyword查询次数：{}'.format(model_name, query_time)
        f.write(out + "\n")
