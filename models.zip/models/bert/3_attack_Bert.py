from my_classifier import batch_predicts
# from itertools import combinations, product

import re, time, ast, argparse, sys
import pandas as pd
import numpy as np


def eval_nonan(element):
    if isinstance(element, str):
        return ast.literal_eval(element)
    return element


def csv2dict_tuple(csv_file):
    input_df = pd.read_csv(csv_file)
    input_df = input_df.applymap(eval_nonan)

    #############keyword以text为column时
    input_dic = input_df.to_dict(orient='list')
    for i in input_dic.values():
        while np.nan in i:
            i.remove(np.nan)
    return input_dic


def csv2dict_onlystr(csv_file):
    input_df = pd.read_csv(csv_file)

    #############keyword以text为column时
    input_dic = input_df.to_dict(orient='list')
    for i in input_dic.values():
        while np.nan in i:
            i.remove(np.nan)
    return input_dic


def perturb_ratio(text, words_tmp):
    changed_num = 0
    for i in words_tmp:
        changed_num = changed_num + len(i)
    # print(changed_num)

    text = re.sub('[^\u4e00-\u9fa5]+', '', text)
    all_num = len(text)

    # ratio = format(, '.4f')  # 计算修改率，保留4位
    ratio = round(changed_num / all_num, 4)
    return ratio


def get_attacker_df(lasttext, mode, lastchanged, keyword, generated):
    attacker_all = []
    for i, candidate in enumerate(generated):
        attack_example = lasttext
        attack_changed = lastchanged[:]
        attack_changed.append(keyword)
        attack_example = attack_example.replace(keyword, candidate, 1)
        attacker_one = (attack_example, mode, attack_changed)
        attacker_all.append(attacker_one)

    attacker_df_tmp = pd.DataFrame(attacker_all, columns=["Examples", "Mode", "ChangedWords"])
    attacker_df_tmp.drop_duplicates(subset=['Examples'], keep='first', inplace=True)
    # attacker_df_tmp.to_csv('/data/gzc/works/similarity_shop/models/bert/tmp/attacker_test.csv', index=False)

    return attacker_df_tmp


def my_attack(data_file, res_original):
    res_original_text = res_original.index[0]
    res_original_label = int(res_original.iloc[0, 0])
    res_original_confidence = res_original.iloc[0, 1]

    res_df = batch_predicts(data_file)
    global query_time
    query_time = query_time + data_file.shape[0]
    # res_df.to_csv('/data/gzc/works/similarity_shop/models/bert/tmp/finalpredict_test.csv', index_label='Examples')

    for i, row in enumerate(res_df.itertuples()):
        res_attack_example = getattr(row, 'Index')
        res_attack_label = eval_nonan(getattr(row, 'Label'))
        res_attack_confidence = getattr(row, 'Confidence')
        res_attack_mode = getattr(row, 'Mode')
        res_attack_words = getattr(row, 'ChangedWords')

        if res_attack_label == res_original_label:
            confidence_diff = res_original_confidence - res_attack_confidence
            if confidence_diff > 0.4:
                ratio = perturb_ratio(res_original_text, res_attack_words)
                attack_succeed = ['Succeed', ratio, res_attack_mode, res_attack_example]
                return attack_succeed
        else:
            # print('####################################不同')
            # print('Examples:{}'.format(getattr(row, 'Index')))
            # print('Original:{}'.format(res_original_text))
            # print('Words,{},{}'.format(type(res_attack_words), getattr(row, 'ChangedWords')))
            ratio = perturb_ratio(res_original_text, res_attack_words)
            # confidence_diff = res_original_confidence + res_attack_confidence
            attack_succeed = ['Succeed', ratio, res_attack_mode, res_attack_example]
            return attack_succeed

    ################## 生成失败，返回conf最小的样本信息:样本/类别/改词
    getmin_index = res_df["Confidence"].idxmin()
    attack_failed = ['Failed', getmin_index, list(res_df.at[getmin_index, 'Mode']),
                     res_df.at[getmin_index, 'ChangedWords']]

    return attack_failed


parser = argparse.ArgumentParser(description='Configuration')
parser.add_argument('--model', default='TextCNN', type=str, required=True,
                    help='Bert,TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer')
parser.add_argument('--mode', default='all', type=str, help='all,morphology,phonetics,semantics,simple')
parser.add_argument('--word', default=False, type=bool, help='True for word, False for char')
args = parser.parse_args()
while len(sys.argv) > 1:
    sys.argv.pop()

if __name__ == '__main__':

    # model_name = 'Bert'  # 八选一：Bert,TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer
    # mode = 'all'  # 四选一：all,morphology,phonetics,semantics,simple
    model_name = args.model
    mode = args.mode

    result_keywords_file = '/data/gzc/works/similarity_shop/result/%s__keywords.csv' % model_name
    result_generate_file = '/data/gzc/works/similarity_shop/result/%s__%s__generated.csv' % (model_name, mode)

    keywords_dict = csv2dict_onlystr(result_keywords_file)
    generate_dict = csv2dict_tuple(result_generate_file)
    assert len(generate_dict) == len(keywords_dict), 'keyword和generate文件内样本数不同'

    ################## 生成记录文件，并初始化(清空)
    record_path = "/data/gzc/works/similarity_shop/result/%s__%s__Record.txt" % (model_name, mode)
    file = open(record_path, 'w').close()

    all_time_start = time.time()

    max_rate = 0.5
    final_res = {}
    Failed = 0
    Succeed = 0
    global query_time
    query_time = 0

    for i, text_base in enumerate(generate_dict, start=1):

        one_time_start = time.time()
        keywords = keywords_dict[text_base]
        generated = generate_dict[text_base]

        ################## 获取原文本base的结果
        base_df = pd.DataFrame(index=range(1), columns=["Examples", "Mode", "ChangedWords"])
        base_df.at[0, 'Examples'] = text_base
        changed_init = []
        res_original = batch_predicts(base_df)
        query_time = query_time + base_df.shape[0]
        # res_original.to_csv('/data/gzc/works/similarity_shop/models/bert/tmp/base%d1.csv' % i)

        ################## 开始生成文本并攻击
        x = int(max_rate * len(keywords))
        text = text_base
        for num in range(1, x + 1):
            index = num - 1
            single_keyword = keywords[index]
            single_generate = generated[index]
            if num == 1:
                changed_init = []
                attack_df = get_attacker_df(text, mode, changed_init, single_keyword, single_generate)
                attack_res = my_attack(attack_df, res_original)
            else:
                attack_df = get_attacker_df(text, mode, changed_2, single_keyword, single_generate)
                attack_res = my_attack(attack_df, res_original)

            ################## 如果成功则跳出循环，否则循输入下一个keyword

            if attack_res[0] == 'Failed':
                text = attack_res[1]
                changed_2 = attack_res[3]
            elif attack_res[0] == 'Succeed':
                break

        ################## 单个文本结束，分析结果下进入下一个文本
        if attack_res[0] == 'Failed':
            tmp_res = (text_base, 'Failed')
            if num == x:
                Failed = Failed + 1
        elif attack_res[0] == 'Succeed':
            Succeed = Succeed + 1
            # tmp_res = '第{}组，扰动率{},类型{},攻击成功:{}'.format(i, attack_res[1], attack_res[2], attack_res[3])
            # tmp_Rate = str(attack_res[1] * 100)[0:5] + '%'
            tmp_Rate = round(attack_res[1], 6)
            tmp_Ad_Example = attack_res[3]
            tmp_res = (text_base, 'Succeed', tmp_Rate, mode, tmp_Ad_Example)

        ################## 一个文本结束，记录单个结果
        one_time_end = time.time()
        one_run_time = round(one_time_end - one_time_start, 4)
        with open(record_path, 'a') as f:
            if len(tmp_res) == 2:
                out = '第{}组文本, {}, 耗时{}'.format(i, tmp_res[1], one_run_time)
            else:
                out = '第{}组文本, {}, 耗时{}, {}'.format(i, tmp_res[1], one_run_time, tmp_res[4])
            f.write(out + "\n")
        print('第{}个文本攻击结束，结果{}'.format(i, tmp_res[1]))

        ################## 更新总结果
        one_final_res = {tmp_res[0]: tmp_res[1:]}
        final_res.update(one_final_res)



    ################## 输出样本数与时间
    all_time_end = time.time()
    run_time = all_time_end - all_time_start
    print('共{}个样本，总耗时{}秒,即:{}'.format(len(generate_dict), run_time, time.strftime("%H:%M:%S", time.gmtime(run_time))))

    ################## 输出样本生成结果，以及csv记录表
    SuccessRate = round(Succeed / (Succeed + Failed), 4)
    print('模式{}下，共{}例文本，其中成功{}例,失败{}例,有效生成比{}'.format(mode, Failed + Succeed, Succeed, Failed, SuccessRate))
    final_res_df = pd.DataFrame.from_dict(final_res, orient='index',
                                          columns=['Result', 'Rate', 'Mode', 'Example'], )
    final_res_df.to_csv('/data/gzc/works/similarity_shop/result/%s__%s__FinalRes.csv' % (model_name, mode),
                        index_label='Text')

    with open('/data/gzc/works/similarity_shop/Record_Query.txt', 'a') as f:
        out = '############ 模型{}, 模式{}, generate查询次数：{}'.format(model_name, mode, query_time)
        f.write(out + "\n")
