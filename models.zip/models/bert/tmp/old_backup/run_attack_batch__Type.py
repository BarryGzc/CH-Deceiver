from my_classifier import predicts, batch_predicts
from itertools import combinations, product

import jieba, re, pickle, time, ast
import pandas as pd
import numpy as np


def eval_nonan(element):
    if isinstance(element, str):
        return ast.literal_eval(element)


def csv2dict_tuple(csv_file):
    input_df = pd.read_csv(csv_file)
    input_df = input_df.applymap(eval_nonan)

    #############keyword以text为column时
    input_dic = input_df.to_dict(orient='list')
    for i in input_dic.values():
        while np.nan in i:
            i.remove(np.nan)
    return input_dic


def csv2dict_onlystr(csv_file):
    input_df = pd.read_csv(csv_file)

    #############keyword以text为column时
    input_dic = input_df.to_dict(orient='list')
    for i in input_dic.values():
        while np.nan in i:
            i.remove(np.nan)
    return input_dic


def perturb_ratio(text, words_tmp):
    changed_num = 0
    for i in words_tmp:
        changed_num = changed_num + len(i)
    # print(changed_num)

    text = re.sub('[^\u4e00-\u9fa5]+', '', text)
    all_num = len(text)

    # ratio = format(, '.4f')  # 计算修改率，保留4位
    ratio = round(changed_num / all_num, 4)
    return ratio


def get_attacker_df(lasttext, lasttype, lastchanged, keyword, generated):
    attacker_all = []
    for i, candidate in enumerate(generated):
        attack_example = lasttext
        attack_changed = lastchanged[:]
        attack_changed.append(keyword)
        attack_type = lasttype[:]
        attack_example = attack_example.replace(keyword, candidate, 1)
        if i < 2:  # 形2
            attack_type.append('A')
        elif i < 4:  # 音2
            attack_type.append('B')
        elif i < 7:  # 意3
            attack_type.append('C')
        elif i < 9:  # 基2
            attack_type.append('D')
        attack_type = list(set(attack_type))  # 去重，无序
        attacker_one = (attack_example, ''.join(attack_type), attack_changed)
        attacker_all.append(attacker_one)

    attacker_df_tmp = pd.DataFrame(attacker_all, columns=["Examples", "Type", "ChangedWords"])
    attacker_df_tmp.drop_duplicates(subset=['Examples'], keep='first', inplace=True)
    # attacker_df_tmp.to_csv('/data/gzc/works/similarity/models/bert/tmp/attacker_test.csv', index=False)

    return attacker_df_tmp


def my_attack(data_file, res_original):
    res_original_text = res_original.index[0]
    res_original_label = int(res_original.iloc[0, 0])
    res_original_confidence = res_original.iloc[0, 1]

    res_df = batch_predicts(data_file)
    # save_variable(res_df, '/data/gzc/works/similarity/models/bert/tmp/one_predict')

    res_df.to_csv('/data/gzc/works/similarity/models/bert/tmp/finalpredict_test.csv', index_label='Examples')

    for i, row in enumerate(res_df.itertuples()):
        res_attack_example = getattr(row, 'Index')
        res_attack_label = eval_nonan(getattr(row, 'Label'))
        res_attack_confidence = getattr(row, 'Confidence')
        res_attack_type = getattr(row, 'Type')
        res_attack_words = getattr(row, 'ChangedWords')

        if res_attack_label == res_original_label:
            confidence_diff = res_original_confidence - res_attack_confidence
            if confidence_diff > 0.4:
                ratio = perturb_ratio(res_original_text, res_attack_words)
                attack_succeed = ['Succeed', ratio, res_attack_type, res_attack_example]
                return attack_succeed
        else:
            #print('####################################不同')
            #print('Examples:{}'.format(getattr(row, 'Index')))
            #print('Original:{}'.format(res_original_text))
            #print('Words,{},{}'.format(type(res_attack_words), getattr(row, 'ChangedWords')))
            ratio = perturb_ratio(res_original_text, res_attack_words)
            # confidence_diff = res_original_confidence + res_attack_confidence
            attack_succeed = ['Succeed', ratio, res_attack_type, res_attack_example]
            return attack_succeed

    ################## 生成失败，返回conf最小的样本信息:样本/类别/改词
    getmin_index = res_df["Confidence"].idxmin()
    attack_failed = ['Failed', getmin_index, list(res_df.at[getmin_index, 'Type']),
                     res_df.at[getmin_index, 'ChangedWords']]

    return attack_failed


if __name__ == '__main__':

    result_keywords_file = '/data/gzc/works/similarity/models/bert/tmp/keywords.csv'
    result_generate_file = '/data/gzc/works/similarity/tmp/generated.csv'

    keywords_dict = csv2dict_onlystr(result_keywords_file)
    generate_dict = csv2dict_tuple(result_generate_file)
    assert len(generate_dict) == len(keywords_dict), 'keyword和generate文件内样本数不同'

    ################## 生成记录文件，并初始化(清空)
    record_path = "/data/gzc/works/similarity/models/bert/result/attack_record.txt"
    file = open(record_path, 'w').close()

    all_time_start = time.time()

    max_rate = 0.5
    final_res = {}
    Failed = 0
    Succeed = 0

    for i, text_base in enumerate(generate_dict, start=1):
        keywords = keywords_dict[text_base]
        generated = generate_dict[text_base]

        ################## 获取原文本base的结果
        base_df = pd.DataFrame(index=range(1), columns=["Examples", "Type", "ChangedWords"])
        base_df.at[0, 'Examples'] = text_base
        type_init = []
        changed_init = []
        res_original = batch_predicts(base_df)
        # res_original.to_csv('/data/gzc/works/similarity/models/bert/tmp/base%d1.csv' % i)

        ################## 开始生成文本并攻击
        x = int(max_rate * len(keywords))
        text = text_base
        for num in range(1, x + 1):
            index = num - 1
            single_keyword = keywords[index]
            single_generate = generated[index]
            if num == 1:
                type_init = []
                changed_init = []
                attack_df = get_attacker_df(text, type_init, changed_init, single_keyword, single_generate)
                attack_res = my_attack(attack_df, res_original)
            else:
                attack_df = get_attacker_df(text, type_2, changed_2, single_keyword, single_generate)
                attack_res = my_attack(attack_df, res_original)

            ################## 如果成功则跳出循环，否则循输入下一个keyword

            if attack_res[0] == 'Failed':
                text = attack_res[1]
                type_2 = attack_res[2]
                changed_2 = attack_res[3]
            elif attack_res[0] == 'Succeed':
                break

        ################## 单个文本结束，分析结果下进入下一个文本
        if attack_res[0] == 'Failed':
            tmp_res = (text, 'Failed')
            if num == x:
                Failed = Failed + 1
        elif attack_res[0] == 'Succeed':
            Succeed = Succeed + 1
            # tmp_res = '第{}组，扰动率{},类型{},攻击成功:{}'.format(i, attack_res[1], attack_res[2], attack_res[3])
            # tmp_Rate = str(attack_res[1] * 100)[0:5] + '%'
            tmp_Rate = round(attack_res[1], 6)
            tmp_Type = attack_res[2]
            tmp_Ad_Example = attack_res[3]
            tmp_res = (text, 'Succeed', tmp_Rate, tmp_Type, tmp_Ad_Example)

        ################## 一个文本结束，记录单个结果
        with open(record_path, 'a') as f:
            if len(tmp_res) == 2:
                out = '第{}组文本, {}'.format(i, tmp_res[1])
            else:
                out = '第{}组文本, {}, {}'.format(i, tmp_res[1], tmp_res[4])
            f.write(out + "\n")

        ################## 更新总结果
        one_final_res = {tmp_res[0]: tmp_res[1:]}
        final_res.update(one_final_res)
        # save_variable(final_res, '/data/gzc/works/similarity/models/bert/tmp/all_final')

    ################## 输出样本数与时间
    all_time_end = time.time()
    run_time = all_time_end - all_time_start
    print('共%d个样本，耗时%f秒' % (len(generate_dict), run_time))
    print(time.strftime("总耗时：%H:%M:%S", time.gmtime(all_time_end - all_time_start)))

    ################## 输出样本生成结果，以及csv记录表
    SuccessRate = round(Succeed / (Succeed + Failed), 4)
    print('共{}例文本，其中成功{}例,失败{}例,有效生成比{}'.format(Failed + Succeed, Succeed, Failed, SuccessRate))
    final_res_df = pd.DataFrame.from_dict(final_res, orient='index',
                                          columns=['Result', 'Rate', 'Type', 'Example'])
    final_res_df.to_csv('/data/gzc/works/similarity/models/bert/tmp/Final_res.csv')
