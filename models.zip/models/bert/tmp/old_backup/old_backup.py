'''
！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！keywords
from single_classifier import predicts
import jieba, re, pickle
import pandas as pd


def save_variable(v, filename):
    f = open(filename, 'wb')
    pickle.dump(v, f)
    f.close()
    return filename


def load_variavle(filename):
    f = open(filename, 'rb')
    r = pickle.load(f)
    f.close()
    return r


def key(text, ratio):
    # text_token = re.sub("[\s+\.\!\/_,$%^*(+\"\'；：:“”．]+|[+——！，。？?、~@#￥%……&*（）]+", "", text)
    text_token = re.sub('[^\u4e00-\u9fa5]+', '', text)
    tokens = jieba.lcut(text_token, cut_all=False)

    text_candidate_set = [text]
    for token in tokens:
        text_candidate_set.append(text.replace(token, '', 1))

    res_dic = predicts(text_candidate_set)

    res = []
    for text_candidate in res_dic:
        res.append(res_dic[text_candidate])

    for i in range(len(res)):
        if res[i][0] == res[0][0]:
            confidence_diff = abs(res[i][1] - res[0][1])
        else:
            confidence_diff = abs(res[i][1] + res[0][1])
        res[i].append(confidence_diff)

    keywords = []
    for idx, score in sorted(enumerate(res[1:]), key=lambda x: x[1][2], reverse=True):
        keywords.append(tokens[idx])

    keywords_simple = sorted(set(keywords), key=keywords.index)

    keywords_simple_final = keywords_simple[0:int(ratio * len(keywords_simple)) + 1]

    return keywords_simple_final


if __name__ == '__main__':

    texts = []
    with open('/data/gzc/works/similarity/models/bert/data/texts_5+100_300.csv') as f:
        data = f.readlines()
    for i in data:
        texts.append(i.rstrip('\n'))

    ratio = 0.5  # 取前0.5的关键词
    res = []
    for text in texts:
        text2keywords = key(text, ratio)
        res.append(text2keywords)

    print(res)

    res_dict = dict(zip(texts, res))

    # res_df = pd.DataFrame.from_dict(res_dict, orient='index')
    # res_df.to_csv('keworkds_res.csv')
    save_variable(res_dict, '/data/gzc/works/similarity/models/bert/Attack/300_res_keywords')

    # save_variable(res_dict, 'result_dic_keywords_300')
    # save_variable(res_dict, '/data/gzc/works/similarity/result_dic_keywords_300')


'''

'''
！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！run_attack_batch

from my_classifier import predicts, batch_predicts
from itertools import combinations, product

import jieba, re, pickle, time
import pandas as pd
import numpy as np


def save_variable(v, filename):
    f = open(filename, 'wb')
    pickle.dump(v, f)
    f.close()
    return filename


def csv2dict(csv_file):
    input_df = pd.read_csv(csv_file)

    #############keyword以text为column时
    input_dic = input_df.to_dict(orient='list')
    for i in input_dic.values():
        while np.nan in i:
            i.remove(np.nan)
    return input_dic


def dict_slicer(x_dict, num):
    new = {}
    for i, (k, v) in enumerate(x_dict.items()):
        new[k] = v
        if i == num - 1:
            return new


def generate_conf(confs):
    for conf in product(*confs.values()):
        yield {k: v for k, v in zip(confs.keys(), conf)}


def perturb_ratio(text, words_tmp):
    changed_num = 0
    for i in words_tmp:
        changed_num = changed_num + len(i)
    # print(changed_num)

    text = re.sub('[^\u4e00-\u9fa5]+', '', text)
    all_num = len(text)

    # ratio = format(, '.4f')  # 计算修改率，保留4位
    ratio = round(changed_num / all_num, 4)
    return ratio


def batch_attack_original(data_file):
    res_df = batch_predicts(data_file)
    # res_df.to_csv('/data/gzc/works/similarity/models/bert/Attack/aaa.csv')

    return res_df


def get_attacker_df(text_original, keywords, candidate_words, change_ratio):
    all_dict = dict(zip(keywords, candidate_words))
    query_time = 0

    x = int(change_ratio * len(keywords)) + 1
    attacker_df = pd.DataFrame(columns=["Type", "Examples", 'ChangedWords'])

    for num in range(x):

        attacker_all = []
        for words_tmp in combinations(keywords, num):
            example_dict = {}

            for i in range(num):
                example_dict[words_tmp[i]] = all_dict[words_tmp[i]]

            examples_set = generate_conf(example_dict)
            for examples_tmp in examples_set:
                attack_example = text
                attack_type = []
                for x in examples_tmp:
                    attack_example = attack_example.replace(x, examples_tmp[x], 1)
                    if example_dict[x].index(examples_tmp[x]) < 2:  # 形2
                        attack_type.append('A')
                    elif example_dict[x].index(examples_tmp[x]) < 5:  # 音3
                        attack_type.append('B')
                    elif example_dict[x].index(examples_tmp[x]) < 7:  # 意2
                        attack_type.append('C')
                    elif example_dict[x].index(examples_tmp[x]) == 7:  # 基1
                        attack_type.append('D')

                attacker_one = (''.join(attack_type), attack_example, tuple(examples_tmp.keys()))
                attacker_all.append(attacker_one)
        attacker_df_tmp = pd.DataFrame(attacker_all, columns=["Type", "Examples", 'ChangedWords'])
        attacker_df = attacker_df.append(attacker_df_tmp)

    # attacker_df.to_csv('/data/gzc/works/similarity/models/bert/Attack/BatchAttack_texts3.csv', index=False)

    return attacker_df


def batch_attack(data_file):
    res_df = batch_predicts(data_file)
    res_df.to_csv('/data/gzc/works/similarity/models/bert/Attack/aaa.csv', index=False)

    res_original_text = res_df.index[0]
    res_original_label = res_df.iloc[0, 0]
    res_original_confidence = res_df.iloc[0, 1]

    for i, row in enumerate(res_df.itertuples()):
        if i == 0:
            continue
        else:
            res_attack_example = getattr(row, 'Index')
            res_attack_label = getattr(row, 'Label')
            res_attack_confidence = getattr(row, 'Confidence')
            res_attack_type = getattr(row, 'Type')
            res_attack_words = getattr(row, 'ChangedWords')

        query_time = i

        if res_attack_label == res_original_label:
            confidence_diff = res_original_confidence - res_attack_confidence
            if confidence_diff > 0.4:
                ratio = perturb_ratio(res_original_text, res_attack_words)
                attack_succeed = [query_time, ratio, res_attack_type, res_attack_example, confidence_diff]
                return attack_succeed
        else:
            ratio = perturb_ratio(res_original_text, res_attack_words)
            confidence_diff = res_original_confidence + res_attack_confidence
            attack_succeed = [query_time, ratio, res_attack_type, res_attack_example, confidence_diff]
            return attack_succeed

    return 'Attack failed'


def get_attacker_df_num(text_original, keywords, candidate_words, num):
    all_dict = dict(zip(keywords, candidate_words))

    attacker_all = []
    for words_tmp in combinations(keywords, num):
        example_dict = {}

        for i in range(num):
            example_dict[words_tmp[i]] = all_dict[words_tmp[i]]

        examples_set = generate_conf(example_dict)
        for examples_tmp in examples_set:
            attack_example = text
            attack_type = []
            for x in examples_tmp:
                attack_example = attack_example.replace(x, examples_tmp[x], 1)
                if example_dict[x].index(examples_tmp[x]) < 2:  # 形2
                    attack_type.append('A')
                elif example_dict[x].index(examples_tmp[x]) < 5:  # 音3
                    attack_type.append('B')
                elif example_dict[x].index(examples_tmp[x]) < 7:  # 意2
                    attack_type.append('C')
                elif example_dict[x].index(examples_tmp[x]) == 7:  # 基1
                    attack_type.append('D')
            attacker_one = (''.join(attack_type), attack_example, tuple(examples_tmp.keys()))
            attacker_all.append(attacker_one)
    attacker_df_tmp = pd.DataFrame(attacker_all, columns=["Type", "Examples", "ChangedWords"])

    attacker_df_tmp.drop_duplicates(subset=['Examples'], keep='first', inplace=True)

    # attacker_df_tmp.to_csv('/data/gzc/works/similarity/models/bert/Attack/BatchAttack_texts3_tmp.csv', index=False)

    return attacker_df_tmp


def batch_attack_num(data_file, sum_query_times, res_original):
    res_original_text = res_original.index[0]
    res_original_label = res_original.iloc[0, 0]
    res_original_confidence = res_original.iloc[0, 1]

    res_df = batch_predicts(data_file)
    res_df.to_csv('/data/gzc/works/similarity/models/bert/Attack/aaa.csv')

    for i, row in enumerate(res_df.itertuples()):
        res_attack_example = getattr(row, 'Index')
        res_attack_label = getattr(row, 'Label')
        res_attack_confidence = getattr(row, 'Confidence')
        res_attack_type = getattr(row, 'Type')
        res_attack_words = getattr(row, 'ChangedWords')

        query_times = i + sum_query_times

        if res_attack_label == res_original_label:
            confidence_diff = res_original_confidence - res_attack_confidence
            if confidence_diff > 0.4:
                ratio = perturb_ratio(res_original_text, res_attack_words)
                attack_succeed = [query_times, ratio, res_attack_type, res_attack_example, confidence_diff]
                return attack_succeed
        else:
            ratio = perturb_ratio(res_original_text, res_attack_words)
            confidence_diff = res_original_confidence + res_attack_confidence
            attack_succeed = [query_times, ratio, res_attack_type, res_attack_example, confidence_diff]
            return attack_succeed

    return 'Attack failed'


if __name__ == '__main__':

    result_keywords_file = '/data/gzc/works/similarity/models/bert/tmp/keywords.csv'
    result_generate_file = '/data/gzc/works/similarity/tmp/generated.csv'

    keywords_dict = csv2dict(result_keywords_file)
    generate_dict = csv2dict(result_generate_file)

    record_path = "/data/gzc/works/similarity/models/bert/result/attack_record.txt"
    file = open(record_path, 'w').close()  # 清空记录文件

    # final_res_print = []
    final_res = {}
    Failed = 0
    Succeed = 0
    for i, text in enumerate(generate_dict, start=1):
        keywords = keywords_dict[text]
        generated = generate_dict[text]

        all_time_start = time.time()

        attack_res0 = get_attacker_df_num(text, keywords, generated, 0)
        res_original = batch_attack_original(attack_res0)

        change_ratio = 0.4
        x = int(change_ratio * len(keywords))
        if x < 1:
            x = 1
        elif x > 3:
            x = 3

        sum_query_times = 0

        for num in range(1, x + 1):
            attack_df = get_attacker_df_num(text, keywords, generated, num)
            attack_res = batch_attack_num(attack_df, sum_query_times, res_original)
            tmp_res = {}

            if attack_res == 'Attack failed':
                # tmp_res = '第{}组，攻击失败'.format(i)
                sum_query_times = sum_query_times + attack_df.shape[0]
                tmp_res = (text, 'Failed')
                if num == x:
                    Failed = Failed + 1
                continue
            else:
                all_time_end = time.time()
                Succeed = Succeed + 1
                run_time = all_time_end - all_time_start
                # tmp_res = '第{}组，查询{}次,扰动率{},类型{}，耗时{:2f},攻击成功:{}'.format(i, attack_res[0], attack_res[1], attack_res[2],run_time, attack_res[3])
                tmp_Query = attack_res[0]
                # tmp_Rate = str(attack_res[1] * 100)[0:5] + '%'
                tmp_Rate = round(attack_res[1], 6)
                tmp_Type = attack_res[2]
                tmp_Time = round(run_time, 2)
                tmp_Ad_Example = attack_res[3]
                tmp_res = (text, 'Succeed', tmp_Query, tmp_Rate, tmp_Type, tmp_Time, tmp_Ad_Example)
                break

        ################## 一个文本结束，记录单个结果
        with open(record_path, 'a') as f:
            if len(tmp_res) == 2:
                out = '第{}组文本, {}'.format(i, tmp_res[1])
            else:
                out = '第{}组文本, {}, {}'.format(i, tmp_res[1], tmp_res[6])
            f.write(out + "\n")

        ################## 更新总结果
        tmp_res = {tmp_res[0]: tmp_res[1:]}
        final_res.update(tmp_res)
        save_variable(final_res, '/data/gzc/works/similarity/models/bert/Attack/300_final_resFFFF')

    ################## 输出样本生成结果，以及csv记录表
    SuccessRate = round(Succeed / (Succeed + Failed), 4)
    print('共{}例文本，其中成功{}例,失败{}例,有效生成比{}'.format(Failed + Succeed, Succeed, Failed, SuccessRate))

    final_res_df = pd.DataFrame.from_dict(final_res, orient='index',
                                          columns=['Result', 'Query', 'Rate', 'Type', 'Time', 'Example'])
    final_res_df.to_csv('/data/gzc/works/similarity/models/bert/Attack/300_Final_resFFFFF.csv')


'''