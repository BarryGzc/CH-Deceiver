#!/usr/bin/env bash

export BERT_BASE_DIR=chinese_L-12_H-768_A-12
export TASK_NAME=senti
export MY_DATASET=data
export OUTPUT_PATH=output

python3 batch_classifier.py \
  --task_name=$TASK_NAME \
  --do_predict=true \
  --data_dir=$MY_DATASET \
  --vocab_file=$BERT_BASE_DIR/vocab.txt \
  --bert_config_file=$BERT_BASE_DIR/bert_config.json \
  --init_checkpoint=output935/model.ckpt-15000 \
  --max_seq_length=300 \
  --output_dir=$OUTPUT_PATH

