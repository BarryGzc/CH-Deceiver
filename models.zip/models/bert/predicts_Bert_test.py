from my_classifier import batch_predicts, predicts, comparison_getacc
import pandas as pd

if __name__ == '__main__':
    '''
    texts = ['和图差不多，只是不大呀，上午赔平，下午送到，苹果还冰冰凉凉的感觉！看纹理应甜',
             'jd自营的就是货真价实！！！',
             '第一次在京东上买水果，实物和图片麦太多了吧，小小的，以后买水果还是去水果店买比较好',
             '整人本觉得还可以吧，价格方面在厦门还算可以，叫了餐服，服务态度还不，房间感觉不是太抒，用的洁具都很二般',
             '不能预装操作系统，省钱了。独显，玩游戏ts。安装xp系统也挺简单的。',
             '商标贴上去，怎么觉得是人叚的，好用，好失败的购物，老婆直接丢lājītǒngle']
    texts_df = pd.DataFrame(texts, columns=['Text'])    
    '''

    # texts_df = pd.read_csv('/data/gzc/works/similarity_shop/data/texts_2000_shop.csv')

    texts = ['这个哈密瓜还能再小一点么，太失望',
             '硬件和服务还行。但房间面积不算大，隔音效果不是很好，隔壁的同事说能听到我打电话，走廊上的声音也吵醒过我2次。',
             '硬件和服务一般。但房间面积不算大，隔音效果是不很好，隔壁的同事说能听到我打电话，走廊上的声音也炒醒过我2次。',
             '硬件和服务一般。但房间面积不算犬，隔音效果不是很好，隔壁的同事说能听到我打电话，走廊上的声音也炒醒过我2次。',
             '硬件和服务一般。但房间面积不算犬，隔音效果是不很好，隔壁的同事说能听到我打电话，走廊上的声音也炒醒过我2次。'
             ]
    texts_df = pd.DataFrame(texts, columns=['Text'])

    pred_df = predicts(texts_df)
    #acc = comparison_getacc(texts_df, pred_df)
    #print('########### acc：{}'.format(acc))

    # texts_df_batch = pd.read_csv('/data/gzc/works/similarity_shop/models/bert/tmp/test_batch.csv')
    # pred_df_batch = batch_predicts(texts_df_batch)
    # pred_df_batch.to_csv("/data/gzc/works/similarity_shop/models/bert/tmp/PredictRes_label_batch.csv", index=False)
    # batch_acc = comparison_getacc(texts_df, pred_df_batch)
    # print('########### {} ，batch_acc：{}'.format(Simulator, batch_acc))

    # 保存于./tmp/
