import requests, json, time
import pandas as pd
import numpy as np
from aip import AipNlp
from sklearn.metrics import accuracy_score
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.nlp.v20190408 import nlp_client, models
from aliyunsdkalinlp.request.v20200629 import GetSaChGeneralRequest
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.acs_exception.exceptions import ClientException
from aliyunsdkcore.acs_exception.exceptions import ServerException

UNK, PAD = '<UNK>', '<PAD>'


def comparison_getacc(base_file, comp_file):
    base_label = base_file['Label'].tolist()
    comp_label = comp_file['Label'].tolist()

    assert len(base_label) == len(comp_label), 'acc文件内样本数不同，无法对比'
    acc = accuracy_score(np.array(base_label), np.array(comp_label))
    # print("model accuracy is:" + str(acc))

    return acc


def Baidu_predict(model_name, input_df):
    #################################################加载baidu
    APP_ID = '????'       ## ID
    API_KEY = '????'      ## API_KEY
    SECRET_KEY = '???'    ## SECRET_KEY
    client = AipNlp(APP_ID, API_KEY, SECRET_KEY)

    texts = []
    labels = []
    for i, text in enumerate(input_df['Text'].tolist()):
        time_start = time.time()

        result = client.sentimentClassify(text)
        pos_prob = result.get('items')[0]['positive_prob']
        neg_prob = result.get('items')[0]['negative_prob']
        if pos_prob > neg_prob:
            res = [1, pos_prob]
        else:
            res = [0, neg_prob]

        label_back = res[0]
        texts.append(text)
        labels.append(label_back)
        ######## 每次都保存，以免断点
        res_df = pd.DataFrame({'Label': labels, "Text": texts})
        res_df.to_csv('Ch_Deceiver/result_transfer/%s_to_baidu_tmp.csv' % model_name, index=False)

        print("#### 第{}个文本，耗时{}, 倾向{}，{}".format(i + 1, round(time.time() - time_start, 4), label_back, text))

    return res_df


def ALi_predict(model_name, input_df):
    #################################################加载baidu
    client = AcsClient(
        "??????",  ### ID
        "??????",  ### Key
        "cn-hangzhou"
    )
    request = GetSaChGeneralRequest.GetSaChGeneralRequest()
    request.set_ServiceCode("alinlp")

    texts = []
    labels = []
    for i, text in enumerate(input_df['Text'].tolist()):
        time_start = time.time()

        request.set_Text(text)
        response = client.do_action_with_exception(request)
        resp_obj = json.loads(response)
        result = eval(resp_obj['Data'].replace("true", "True"))['result']

        pos_prob = result['positive_prob']
        neg_prob = result['negative_prob']
        if (pos_prob > neg_prob):
            res = [1, pos_prob]
        elif (pos_prob < neg_prob):
            res = [0, neg_prob]
        else:
            raise ValueError('pos_prob=neg_prob')

        label_back = res[0]

        texts.append(text)
        labels.append(label_back)

        ######## 每次都保存，以免断点
        res_df = pd.DataFrame({'Label': labels, "Text": texts})
        res_df.to_csv('Ch_Deceiver/result_transfer/%s_to_ALi_tmp.csv' % model_name, index=False)

        print("#### 第{}个文本，耗时{}, 倾向{}，{}".format(i + 1, round(time.time() - time_start, 4), label_back, text))

    return res_df


def Tencent_predict(model_name, input_df):
    #################################################加载baidu
    cred = credential.Credential("????", "????")   ## ID , Key
    httpProfile = HttpProfile()
    httpProfile.endpoint = "nlp.tencentcloudapi.com"

    clientProfile = ClientProfile()
    clientProfile.httpProfile = httpProfile
    client = nlp_client.NlpClient(cred, "ap-guangzhou", clientProfile)

    req = models.SentimentAnalysisRequest()

    texts = []
    labels = []
    for i, text in enumerate(input_df['Text'].tolist()):
        time_start = time.time()

        if len(text) > 200:
            text = re.sub("[a-zA-Z0-9]", "", text)
            text = re.sub(" ", "", text)
        params = {
            "Text": text
        }
        req.from_json_string(json.dumps(params))
        resp = client.SentimentAnalysis(req)
        result = json.loads(resp.to_json_string())
        pos_prob = result['Positive']
        neg_prob = result['Negative']
        if (pos_prob > neg_prob):
            res = [1, pos_prob]
        elif (pos_prob < neg_prob):
            res = [0, neg_prob]
        else:
            raise ValueError('pos_prob=neg_prob')

        label_back = res[0]
        texts.append(text)
        labels.append(label_back)

        ######## 每次都保存，以免断点
        res_df = pd.DataFrame({'Label': labels, "Text": texts})
        res_df.to_csv('CH_Deceiver/result_transfer/%s_to_Tencent_tmp.csv' % model_name, index=False)

        print("#### 第{}个文本，耗时{}, 倾向{}，{}".format(i + 1, round(time.time() - time_start, 4), label_back, text))

    return res_df


if __name__ == '__main__':

    ### 'Bert','TextCNN', 'TextRNN', 'TextRCNN', 'TextRNN_Att', 'Transformer', 'FastText'
    Simulator = 'FastText'
    ### 'Baidu','ALi', 'Tencent'
    Victim = 'Tencent'

    dataset = 'shop'
    mode = 'all'
    ################################################ Original Text&Label
    base_label = pd.read_csv('CH_Deceiver/data/texts_2000_%s.csv' % (dataset))

    ################################################ Simulator Text&Label
    Examples_from_Simulator_df = pd.read_csv(
        'Ch_Deceiver/result/%s__%s__NewExample.csv' % (dataset, Simulator, mode))
    #.drop([i for i in range(1621)])

    ################################################ Victim Model and predict
    if Victim == 'Baidu':
        transfer_result = Baidu_predict(Simulator, Examples_from_Simulator_df)
    elif Victim == 'ALi':
        transfer_result = ALi_predict(Simulator, Examples_from_Simulator_df)
    elif Victim == 'Tencent':
        transfer_result = Tencent_predict(Simulator, Examples_from_Simulator_df)
    else:
        raise ValueError('Victime must be one of Baidu, ALi, and Tencent')

    ################################################ Comparasion
    tranfer_acc = comparison_getacc(base_label, transfer_result)
    print('########### {} to {} on {}，迁移后acc：{}'.format(Simulator, Victim, dataset, tranfer_acc))
