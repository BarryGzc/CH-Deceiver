# coding: UTF-8
from LAC import LAC
from importlib import import_module
import jieba, re, pickle, time, random, torch,ast
import pandas as pd
import numpy as np

# import torch.nn as nn
import torch.nn.functional as F

UNK, PAD = '<UNK>', '<PAD>'


def softmax(list):
    logits = np.exp(list)
    select_probs = logits / np.sum(logits)
    return select_probs[1]


def clearTxt(line):
    if line != '':
        line = re.sub("[a-zA-Z0-9]", "", line)
        # 去除文本中的中文符号和英文符号
        line = re.sub("[\s+\.\!\/_,$%^*(+\"\'；：:“”．]+|[+——！，。？?、~@#￥%……&*（）]+", "", line)
        line = line.replace('[', '')
        line = line.replace(']', '')
        seg = " ".join(jieba.cut(line, cut_all=False))

    return seg


def biGramHash(sequence, t, buckets):
    t1 = sequence[t - 1] if t - 1 >= 0 else 0
    return (t1 * 14918087) % buckets


def triGramHash(sequence, t, buckets):
    t1 = sequence[t - 1] if t - 1 >= 0 else 0
    t2 = sequence[t - 2] if t - 2 >= 0 else 0
    return (t2 * 14918087 * 18408749 + t1 * 14918087) % buckets





def eval_nonan(element):
    if isinstance(element, str):
        return ast.literal_eval(element)
    return element


def csv2dict_tuple(csv_file):
    input_df = pd.read_csv(csv_file)
    input_df = input_df.applymap(eval_nonan)

    #############keyword以text为column时
    input_dic = input_df.to_dict(orient='list')
    for i in input_dic.values():
        while np.nan in i:
            i.remove(np.nan)
    return input_dic


def csv2dict_onlystr(csv_file):
    input_df = pd.read_csv(csv_file)

    #############keyword以text为column时
    input_dic = input_df.to_dict(orient='list')
    for i in input_dic.values():
        while np.nan in i:
            i.remove(np.nan)
    return input_dic


def perturb_ratio(text, words_tmp):
    changed_num = 0
    for i in words_tmp:
        changed_num = changed_num + len(i)
    # print(changed_num)

    text = re.sub('[^\u4e00-\u9fa5]+', '', text)
    all_num = len(text)

    # ratio = format(, '.4f')  # 计算修改率，保留4位
    ratio = round(changed_num / all_num, 4)
    return ratio




if __name__ == '__main__':
    ############## Model Initialization
    model_name = 'DPCNN'  # TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer
    dataset = 'Shopping10'
    embedding = 'embedding_weibo_word_c.npz'  # 词向量

    ################################################ 加载模型
    x = import_module('models.' + model_name)
    config = x.Config(dataset, embedding)
    np.random.seed(1)
    torch.manual_seed(1)
    torch.cuda.manual_seed_all(1)
    torch.backends.cudnn.deterministic = True
    vocab = pickle.load(open(config.vocab_path, 'rb'))
    model = x.Model(config).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    model.load_state_dict(torch.load(dataset + '/model_saved/' + model_name + '.ckpt'))
    tokenizer = lambda x: x.split(' ')  # 以空格隔开，word-level

    ############## Get Keywords
    base_text_path = '/data/gzc/works/similarity_shop/data/texts_1000_test.csv'
    base_text = pd.read_csv(base_text_path)
    all_time_start = time.time()
    keywords = file_key(base_text, model, model_name, config, 0.5)  # 默认取前0.5的关键词

    all_time_end = time.time()
    print('#########################################')
    print('网络{},共{}个文本，总耗时:{}，即 {}'.format(model_name, keywords.shape[1], all_time_end - all_time_start,
                                           time.strftime("%H:%M:%S", time.gmtime(all_time_end - all_time_start))))
    keywords.to_csv('/data/gzc/works/similarity_shop/result/%s__keywords.csv' % model_name, index=0)
