import pandas as pd
from importlib import import_module
from sklearn.metrics import accuracy_score
from utils.predict_def import *
import torch, argparse


def comparison_getacc(base_file, comp_file):
    base_label = base_file['Label'].tolist()
    comp_label = comp_file['Label'].tolist()

    assert len(base_label) == len(comp_label), 'acc文件内样本数不同，无法对比'
    acc = accuracy_score(np.array(base_label), np.array(comp_label))
    # print("model accuracy is:" + str(acc))

    return acc


def build_predict_text(text, config):
    token = tokenizer(text)
    words_line = []
    seq_len = len(token)
    content = []
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))
    content.append((words_line, -1, seq_len))
    x = torch.LongTensor([_[0] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    y = torch.LongTensor([_[1] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))

    # pad前的长度(超过pad_size的设为pad_size)
    seq_len = torch.LongTensor([_[2] for _ in content])

    return (x, seq_len)


def build_predict_fasttext(text):
    lin = text.strip()
    words_line = []
    token = tokenizer(lin)
    seq_len = len(token)
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))

    # fasttext ngram
    buckets = config.n_gram_vocab
    bigram = []
    trigram = []
    # ------ngram------
    for i in range(pad_size):
        bigram.append(biGramHash(words_line, i, buckets))
        trigram.append(triGramHash(words_line, i, buckets))
    words_line = torch.LongTensor([words_line]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    seq_len = torch.LongTensor([seq_len]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    bigram = torch.LongTensor([bigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    trigram = torch.LongTensor([trigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    return words_line, seq_len, bigram, trigram


def predicts(texts_df, model, model_name, config):
    # global checkcnt
    # checkcnt += 1

    if 'Text' in texts_df.columns:
        texts = texts_df['Text'].tolist()
    elif 'Examples' in texts_df.columns:
        texts = texts_df['Examples'].tolist()
    else:
        raise ValueError("Columns不含Text或Examples" % (task_name))

    labels = []
    pros = []
    with torch.no_grad():
        for text in texts:
            # text = " ".join(jieba.lcut(text))
            text = clearTxt(text)
            if model_name == "FastText":
                data = build_predict_fasttext(text)
            else:
                data = build_predict_text(text, config)
            # print(data)
            model.eval()
            outputs = model(data)
            # predic = torch.max(outputs.data, 1)[1].cpu().numpy()
            list = outputs.cpu().numpy().tolist()
            if model_name == 'DPCNN' or model_name == 'TextRCNN':
                if list[0] > list[1]:
                    label = 0
                    pro = 1 - softmax(list)
                else:
                    label = 1
                    pro = softmax(list)
            else:
                if list[0][0] > list[0][1]:
                    label = 0
                    pro = 1 - softmax(list[0])
                else:
                    label = 1
                    pro = softmax(list[0])
            # label = predic
            labels.append(label)
            pros.append(pro)
            # print(label)
    assert len(texts) == len(labels) == len(pros), 'Bug in predict'

    res_dict = {'Label': labels, 'Confidence': pros, 'Text': texts}
    res_df = pd.DataFrame(res_dict)

    return res_df


if __name__ == '__main__':
    base_text = pd.read_csv('/data/gzc/works/similarity_shop/data/texts_2000_shop.csv')

    #TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer
    model_name = 'Transformer'
    corrected_df = pd.read_csv('/data/gzc/works/similarity_shop/result_defense/%s__corrected.csv' % model_name)

    ################################################ 加载模型
    dataset = 'Shopping10'
    embedding = 'embedding_weibo_word_c.npz'  # 词向量
    x = import_module('models.' + model_name)
    config = x.Config(dataset, embedding)
    np.random.seed(1)
    torch.manual_seed(1)
    torch.cuda.manual_seed_all(1)
    torch.backends.cudnn.deterministic = True
    vocab = pickle.load(open(config.vocab_path, 'rb'))
    model = x.Model(config).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    model.load_state_dict(torch.load(dataset + '/model_saved/' + model_name + '.ckpt'))
    tokenizer = lambda x: x.split(' ')  # 以空格隔开，word-level

    text_before = corrected_df['Text_before'].to_frame()
    text_after = corrected_df['Text_after'].to_frame()

    text_before.rename(columns={'Text_before': 'Text'}, inplace=True)
    text_after.rename(columns={'Text_after': 'Text'}, inplace=True)

    text_before_pred = predicts(text_before, model, model_name, config)
    text_after_pred = predicts(text_after, model, model_name, config)

    before_acc = comparison_getacc(base_text, text_before_pred)
    after_acc = comparison_getacc(base_text, text_after_pred)

    print('### {}, Before acc:{}'.format(model_name, before_acc))
    print('### {}, After acc:{}'.format(model_name, after_acc))

    # 保存于./tmp/
