import csv, re, torch, random, argparse
# import torch.nn as nn
import numpy as np
import pandas as pd
import jieba
import torch.nn.functional as F
from importlib import import_module
import pickle as pkl
from sklearn.metrics import accuracy_score
from utils.predict_def import *

# from utils import build_dataset, build_iterator, get_time_dif

UNK, PAD = '<UNK>', '<PAD>'


def comparison_getacc(base_file, comp_file):
    base_label = base_file['Label'].tolist()
    comp_label = comp_file['Label'].tolist()

    assert len(base_label) == len(comp_label), 'acc文件内样本数不同，无法对比'
    acc = accuracy_score(np.array(base_label), np.array(comp_label))
    # print("model accuracy is:" + str(acc))

    return acc


def build_predict_text(text, config):
    token = tokenizer(text)
    words_line = []
    seq_len = len(token)
    content = []
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))
    content.append((words_line, -1, seq_len))
    x = torch.LongTensor([_[0] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    y = torch.LongTensor([_[1] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))

    # pad前的长度(超过pad_size的设为pad_size)
    seq_len = torch.LongTensor([_[2] for _ in content])

    return (x, seq_len)


def build_predict_fasttext(text):
    lin = text.strip()
    words_line = []
    token = tokenizer(lin)
    seq_len = len(token)
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))

    # fasttext ngram
    buckets = config.n_gram_vocab
    bigram = []
    trigram = []
    # ------ngram------
    for i in range(pad_size):
        bigram.append(biGramHash(words_line, i, buckets))
        trigram.append(triGramHash(words_line, i, buckets))
    words_line = torch.LongTensor([words_line]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    seq_len = torch.LongTensor([seq_len]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    bigram = torch.LongTensor([bigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    trigram = torch.LongTensor([trigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    return words_line, seq_len, bigram, trigram


def predicts(texts_df, model, model_name, config):
    # global checkcnt
    # checkcnt += 1

    if 'Text' in texts_df.columns:
        texts = texts_df['Text'].tolist()
    elif 'Examples' in texts_df.columns:
        texts = texts_df['Examples'].tolist()
    else:
        raise ValueError("Columns不含Text或Examples" % (task_name))

    labels = []
    pros = []
    with torch.no_grad():
        for text in texts:
            # text = " ".join(jieba.lcut(text))
            text = clearTxt(text)
            if model_name == "FastText":
                data = build_predict_fasttext(text)
            else:
                data = build_predict_text(text, config)
            # print(data)
            model.eval()
            outputs = model(data)
            # predic = torch.max(outputs.data, 1)[1].cpu().numpy()
            list = outputs.cpu().numpy().tolist()
            if model_name == 'DPCNN' or model_name == 'TextRCNN':
                if list[0] > list[1]:
                    label = 0
                    pro = 1 - softmax(list)
                else:
                    label = 1
                    pro = softmax(list)
            else:
                if list[0][0] > list[0][1]:
                    label = 0
                    pro = 1 - softmax(list[0])
                else:
                    label = 1
                    pro = softmax(list[0])
            # label = predic
            labels.append(label)
            pros.append(pro)
            # print(label)
    assert len(texts) == len(labels) == len(pros), 'Bug in predict'

    res_dict = {'Label': labels, 'Confidence': pros, 'Text': texts}
    res_df = pd.DataFrame(res_dict)

    return res_df


if __name__ == '__main__':
    # 模型准确率 TextCNN: 0.9252 TextRNN: 0.9250, FastText: 0.9287, TextRCNN: 0.9327, TextRNN_Att: 0.9284, DPCNN: 0.9206,Transformer: 0.9252
    ###TextCNN, TextRNN, TextRCNN, TextRNN_Att, DPCNN, Transformer, FastText
    # Simulator = 'Bert'  # 取样本，攻击B
    # Victim = 'TextRNN'  # 被A样本攻击
    mode = 'all'
    base_texts = '/data/gzc/works/similarity_shop/data/texts_2000_shop.csv'
    base_label = pd.read_csv(base_texts)

    simulator_list = ['Bert', 'TextCNN', 'TextRNN', 'TextRCNN', 'TextRNN_Att', 'DPCNN', 'Transformer', 'FastText']
    #simulator_list = ['TextRCNN', 'FastText', 'TextCNN', 'TextRNN', 'TextRNN_Att', 'Transformer', 'DPCNN']
    victim_list = ['TextRCNN', 'FastText', 'TextCNN', 'TextRNN', 'TextRNN_Att', 'Transformer', 'DPCNN']
    for Simulator in simulator_list:
        for Victim in victim_list:
            ################################################ 加载Victim模型
            dataset = 'Shopping10'
            embedding = 'embedding_weibo_word_c.npz'  # 词向量
            x = import_module('models.' + Victim)
            config = x.Config(dataset, embedding)
            np.random.seed(1)
            torch.manual_seed(1)
            torch.cuda.manual_seed_all(1)
            torch.backends.cudnn.deterministic = True
            vocab = pkl.load(open(config.vocab_path, 'rb'))
            model = x.Model(config).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
            model.load_state_dict(torch.load(dataset + '/model_saved/' + Victim + '.ckpt'))
            tokenizer = lambda x: x.split(' ')  # 以空格隔开，word-level

            ################################################ 测试Simulator样本
            Examples_from_Simulator = '/data/gzc/works/similarity_shop/result/%s__%s__NewExample.csv' % (Simulator, mode)
            Examples_from_Simulator_df = pd.read_csv(Examples_from_Simulator)

            transfer_result = predicts(Examples_from_Simulator_df, model, Victim, config)
            tranfer_acc = comparison_getacc(base_label, transfer_result)
            print('########### {} to {}，有效迁移effectiveness：{}'.format(Simulator, Victim, tranfer_acc))
