import csv, re, torch, random
# import torch.nn as nn
import numpy as np
import pandas as pd
import jieba
import torch.nn.functional as F
from importlib import import_module
import pickle as pkl
from sklearn.metrics import accuracy_score
from utils.predict_def import *

# from utils import build_dataset, build_iterator, get_time_dif

UNK, PAD = '<UNK>', '<PAD>'


def comparison_getacc(base_file, comp_file):
    base_label = base_file['Label'].tolist()
    comp_label = comp_file['Label'].tolist()

    assert len(base_label) == len(comp_label), 'acc文件内样本数不同，无法对比'
    acc = accuracy_score(np.array(base_label), np.array(comp_label))
    # print("model accuracy is:" + str(acc))

    return acc


def build_predict_text(text, config):
    token = tokenizer(text)
    words_line = []
    seq_len = len(token)
    content = []
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))
    content.append((words_line, -1, seq_len))
    x = torch.LongTensor([_[0] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    y = torch.LongTensor([_[1] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))

    # pad前的长度(超过pad_size的设为pad_size)
    seq_len = torch.LongTensor([_[2] for _ in content])

    return (x, seq_len)


def build_predict_fasttext(text):
    lin = text.strip()
    words_line = []
    token = tokenizer(lin)
    seq_len = len(token)
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))

    # fasttext ngram
    buckets = config.n_gram_vocab
    bigram = []
    trigram = []
    # ------ngram------
    for i in range(pad_size):
        bigram.append(biGramHash(words_line, i, buckets))
        trigram.append(triGramHash(words_line, i, buckets))
    words_line = torch.LongTensor([words_line]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    seq_len = torch.LongTensor([seq_len]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    bigram = torch.LongTensor([bigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    trigram = torch.LongTensor([trigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    return words_line, seq_len, bigram, trigram


def predicts(texts_df, model, model_name, config):
    # global checkcnt
    # checkcnt += 1

    if 'Text' in texts_df.columns:
        texts = texts_df['Text'].tolist()
    elif 'Examples' in texts_df.columns:
        texts = texts_df['Examples'].tolist()
    elif 'review' in texts_df.columns:
        texts = texts_df['review'].tolist()
    else:
        raise ValueError("Columns不含Text或Examples或review" % (task_name))

    labels = []
    pros = []
    with torch.no_grad():
        for text in texts:
            # text = " ".join(jieba.lcut(text))
            text = clearTxt(text)
            if model_name == "FastText":
                data = build_predict_fasttext(text)
            else:
                data = build_predict_text(text, config)
            # print(data)
            model.eval()
            outputs = model(data)
            # predic = torch.max(outputs.data, 1)[1].cpu().numpy()
            list = outputs.cpu().numpy().tolist()
            if model_name == 'DPCNN' or model_name == 'TextRCNN':
                if list[0] > list[1]:
                    label = 0
                    pro = 1 - softmax(list)
                else:
                    label = 1
                    pro = softmax(list)
            else:
                if list[0][0] > list[0][1]:
                    label = 0
                    pro = 1 - softmax(list[0])
                else:
                    label = 1
                    pro = softmax(list[0])
            # label = predic
            labels.append(label)
            pros.append(pro)
            # print(label)
    assert len(texts) == len(labels) == len(pros), 'Bug in predict'

    res_dict = {'Label': labels, 'Confidence': pros, 'Text': texts}
    res_df = pd.DataFrame(res_dict)

    return res_df


def batch_predicts(texts_df, model, model_name, config):
    attack_text = []
    for index, predict in enumerate(texts_df.values):
        attack_text.append(predict[0])
        attack_text = texts_df['Text'].values.tolist()

    texts = attack_text[:]

    labels = []
    pros = []
    with torch.no_grad():
        for text in texts:
            # text = " ".join(jieba.lcut(text))
            text = clearTxt(text)
            if model_name == "FastText":
                data = build_predict_fasttext(text)
            else:
                data = build_predict_text(text, config)
            # print(data)
            model.eval()
            outputs = model(data)
            # predic = torch.max(outputs.data, 1)[1].cpu().numpy()
            list = outputs.cpu().numpy().tolist()
            if model_name == 'DPCNN' or model_name == 'TextRCNN':
                if list[0] > list[1]:
                    label = 0
                    pro = 1 - softmax(list)
                else:
                    label = 1
                    pro = softmax(list)
            else:
                if list[0][0] > list[0][1]:
                    label = 0
                    pro = 1 - softmax(list[0])
                else:
                    label = 1
                    pro = softmax(list[0])
            # label = predic
            labels.append(label)
            pros.append(pro)
    assert len(texts) == len(labels) == len(pros), 'Bug in predict'

    res_dic = {}
    for i in range(len(texts)):
        res_dic[texts[i]] = [labels[i], pros[i]]

    res_df = pd.DataFrame.from_dict(res_dic, orient='index', columns=['Label', 'Confidence'])

    return res_df


if __name__ == '__main__':
    # 模型准确率 TextCNN: 0.9252 TextRNN: 0.9250, FastText: 0.9287, TextRCNN: 0.9327, TextRNN_Att: 0.9284, DPCNN: 0.9206,Transformer: 0.9252

    model_name = 'TextRNN'  # TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer

    ################################################ 加载模型
    dataset = 'Shopping10'
    embedding = 'embedding_weibo_word_c.npz'  # 词向量
    x = import_module('models.' + model_name)
    config = x.Config(dataset, embedding)
    np.random.seed(1)
    torch.manual_seed(1)
    torch.cuda.manual_seed_all(1)
    torch.backends.cudnn.deterministic = True
    vocab = pkl.load(open(config.vocab_path, 'rb'))
    model = x.Model(config).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    model.load_state_dict(torch.load(dataset + '/model_saved/' + model_name + '.ckpt'))
    tokenizer = lambda x: x.split(' ')  # 以空格隔开，word-level

    '''
    ################################################ 单独测试一个文件
    #texts_df = pd.read_csv('/data/gzc/works/similarity_shop/data/texts_2000_shop.csv')
    #texts_df = pd.read_csv('/data/sdm/Chinese_model/Shopping10/data/test.tsv',sep='\t')



    predicts_result = predicts(texts_df, model, model_name, config)
    predicts_result.to_csv('tmp/PredictRes_%s.csv' % model_name, index=False)

    #predicts_result = batch_predicts(texts_df, model, model_name, config)
    #predicts_result.to_csv('tmp/PredictRes_%s_batch.csv' % model_name, index=False)

    acc = comparison_getacc(texts_df, predicts_result)
    print('########### {}，样本测试准确率：{}'.format(model_name, acc))
    '''

    base_text = pd.read_csv('/data/gzc/works/similarity_shop/data/texts_2000_shop.csv')
    attacker_name = 'PW'  # PW, bug, PSO
    texts_df = pd.read_csv(
        '/data/gzc/works/similarity_backup/openattack/tmp/{}_to_{}_result.csv'.format(attacker_name, model_name))

    predicts_result = predicts(texts_df, model, model_name, config)
    # predicts_result.to_csv('tmp/openattack_{}_to_{}.csv'.format(attacker_name, model_name), index=False)

    acc = comparison_getacc(base_text, predicts_result)
    print('########### {}_to_{}，样本测试准确率：{}'.format(attacker_name, model_name, acc))
