from LAC import LAC
from importlib import import_module
import jieba, re, pickle, time, random, torch,argparse
import pandas as pd
import numpy as np

# import torch.nn as nn
import torch.nn.functional as F

UNK, PAD = '<UNK>', '<PAD>'


def softmax(list):
    logits = np.exp(list)
    select_probs = logits / np.sum(logits)
    return select_probs[1]


def clearTxt(line):
    if line != '':
        line = re.sub("[a-zA-Z0-9]", "", line)
        # 去除文本中的中文符号和英文符号
        line = re.sub("[\s+\.\!\/_,$%^*(+\"\'；：:“”．]+|[+——！，。？?、~@#￥%……&*（）]+", "", line)
        line = line.replace('[', '')
        line = line.replace(']', '')
        seg = " ".join(jieba.cut(line, cut_all=False))

    return seg


def biGramHash(sequence, t, buckets):
    t1 = sequence[t - 1] if t - 1 >= 0 else 0
    return (t1 * 14918087) % buckets


def triGramHash(sequence, t, buckets):
    t1 = sequence[t - 1] if t - 1 >= 0 else 0
    t2 = sequence[t - 2] if t - 2 >= 0 else 0
    return (t2 * 14918087 * 18408749 + t1 * 14918087) % buckets


def build_predict_text(text, config):
    token = tokenizer(text)
    words_line = []
    seq_len = len(token)
    content = []
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))
    content.append((words_line, -1, seq_len))
    x = torch.LongTensor([_[0] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    y = torch.LongTensor([_[1] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))

    # pad前的长度(超过pad_size的设为pad_size)
    seq_len = torch.LongTensor([_[2] for _ in content])

    return (x, seq_len)


def build_predict_fasttext(text):
    lin = text.strip()
    words_line = []
    token = tokenizer(lin)
    seq_len = len(token)
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))

    # fasttext ngram
    buckets = config.n_gram_vocab
    bigram = []
    trigram = []
    # ------ngram------
    for i in range(pad_size):
        bigram.append(biGramHash(words_line, i, buckets))
        trigram.append(triGramHash(words_line, i, buckets))
    words_line = torch.LongTensor([words_line]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    seq_len = torch.LongTensor([seq_len]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    bigram = torch.LongTensor([bigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    trigram = torch.LongTensor([trigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    return words_line, seq_len, bigram, trigram


def predicts(texts_df, model, model_name, config):
    # global checkcnt
    # checkcnt += 1

    if 'Text' in texts_df.columns:
        texts = texts_df['Text'].tolist()
    elif 'Examples' in texts_df.columns:
        texts = texts_df['Examples'].tolist()
    else:
        raise ValueError("Columns不含Text或Examples" % (task_name))

    labels = []
    pros = []
    with torch.no_grad():
        for text in texts:
            # text = " ".join(jieba.lcut(text))
            text = clearTxt(text)
            if model_name == "FastText":
                data = build_predict_fasttext(text)
            else:
                data = build_predict_text(text, config)
            # print(data)
            model.eval()
            outputs = model(data)
            # predic = torch.max(outputs.data, 1)[1].cpu().numpy()
            list = outputs.cpu().numpy().tolist()
            if model_name == 'DPCNN' or model_name == 'TextRCNN':
                if list[0] > list[1]:
                    label = 0
                    pro = 1 - softmax(list)
                else:
                    label = 1
                    pro = softmax(list)
            else:
                if list[0][0] > list[0][1]:
                    label = 0
                    pro = 1 - softmax(list[0])
                else:
                    label = 1
                    pro = softmax(list[0])
            # label = predic
            labels.append(label)
            pros.append(pro)
            # print(label)
    assert len(texts) == len(labels) == len(pros), 'Bug in predict'

    res_dict = {'Label': labels, 'Confidence': pros, 'Text': texts}
    res_df = pd.DataFrame(res_dict)

    return res_df


def key(text, model, model_name, config, ratio=0.5):
    # text_token = re.sub("[\s+\.\!\/_,$%^*(+\"\'；：:“”．]+|[+——！，。？?、~@#￥%……&*（）]+", "", text)
    text_token = re.sub('[^\u4e00-\u9fa5]+', '', text)

    ###########jieba分词
    tokens = jieba.lcut(text_token, cut_all=False)
    ###########百度分词
    # lac = LAC(mode='seg')
    # tokens = lac.run(text_token)

    texts_candidate_set = [text]
    for token in tokens:
        texts_candidate_set.append(text.replace(token, '', 1))

    texts_candidate_df = pd.DataFrame(texts_candidate_set, columns=['Examples'])
    res_dic = predicts(texts_candidate_df, model, model_name, config)

    global query_time
    query_time = query_time + texts_candidate_df.shape[0]

    tokens.insert(0, 'None')
    token_candidate_df = pd.DataFrame(tokens, columns=['Tokens'])
    candidate_df = pd.concat([res_dic, token_candidate_df], axis=1)

    conf = []
    for i in range(len(candidate_df)):
        if candidate_df.at[i, 'Label'] == candidate_df.at[0, 'Label']:
            confidence_diff = abs(candidate_df.at[i, 'Confidence'] - candidate_df.at[0, 'Confidence'])
        else:
            confidence_diff = abs(candidate_df.at[i, 'Confidence'] + candidate_df.at[0, 'Confidence']) - 1
        conf.append(confidence_diff)
    conf_diff = pd.DataFrame(conf, columns=['Confidence_diff'])
    res_df = pd.concat([candidate_df, conf_diff], axis=1)

    res_df.sort_values(by=['Confidence_diff'], inplace=True, ascending=False)

    # res_df.to_csv('/data/gzc/works/similarity_shop/models/bert/tmp/all_diff.csv')

    keywords_all = res_df['Tokens'].tolist()
    keywords_all2 = keywords_all[0:int(ratio * len(tokens)) + 1]
    keywords_final = sorted(set(keywords_all2), key=keywords_all2.index)  # 去重

    return keywords_final


def file_key(file_pd, model, model_name, config, ratio=0.5):
    # 默认取前0.5的关键词

    texts = file_pd['Text'].to_list()

    res = []
    for text in texts:
        text2keywords = key(text, model, model_name, config, ratio)
        res.append(text2keywords)

    res_dict = dict(zip(texts, res))
    # res_df=pd.DataFrame.from_dict(res_dict, orient='index')
    res_df = pd.DataFrame(dict([(k, pd.Series(v)) for k, v in res_dict.items()]))  # 解决字典值元素长度不对齐的问题

    return res_df


parser = argparse.ArgumentParser(description='Configuration')
parser.add_argument('--model', default='TextCNN', type=str, required=True,
                    help='TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer')
parser.add_argument('--word', default=False, type=bool, help='True for word, False for char')
parser.add_argument('--data', default=False, type=str, help='Original Text_path')
args = parser.parse_args()

if __name__ == '__main__':
    global query_time
    query_time = 0

    ############## Model Initialization
    #model_name = 'TextCNN'  # TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer
    model_name = args.model
    original_data_file = args.data

    ################################################ 加载模型
    dataset = 'Shopping10'
    embedding = 'embedding_weibo_word_c.npz'  # 词向量

    x = import_module('models.' + model_name)
    config = x.Config(dataset, embedding)
    np.random.seed(1)
    torch.manual_seed(1)
    torch.cuda.manual_seed_all(1)
    torch.backends.cudnn.deterministic = True
    vocab = pickle.load(open(config.vocab_path, 'rb'))
    model = x.Model(config).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    model.load_state_dict(torch.load(dataset + '/model_saved/' + model_name + '.ckpt'))
    tokenizer = lambda x: x.split(' ')  # 以空格隔开，word-level

    ############## Get Keywords
    base_text_path = original_data_file
    base_text = pd.read_csv(base_text_path)
    all_time_start = time.time()
    keywords = file_key(base_text, model, model_name, config, 0.5)  # 默认取前0.5的关键词

    all_time_end = time.time()
    print('#########################################')
    print('网络{},共{}个文本，总耗时:{}，即 {}'.format(model_name, 1+keywords.shape[1], all_time_end - all_time_start,
                                           time.strftime("%H:%M:%S", time.gmtime(all_time_end - all_time_start))))
    keywords.to_csv('/data/gzc/works/similarity_shop/result/%s__keywords.csv' % model_name, index=0)

    with open('/data/gzc/works/similarity_shop/Record_Query.txt', 'a') as f:
        out = '############ 模型{}, keyword查询次数：{}'.format(model_name, query_time)
        f.write(out + "\n")
