import pandas as pd
from importlib import import_module
from sklearn.metrics import accuracy_score
from utils.predict_def import *
import torch, argparse


def comparison_getacc(base_file, comp_file):
    base_label = base_file['Label'].tolist()
    comp_label = comp_file['Label'].tolist()

    assert len(base_label) == len(comp_label), 'acc文件内样本数不同，无法对比'
    acc = accuracy_score(np.array(base_label), np.array(comp_label))
    # print("model accuracy is:" + str(acc))

    return acc


def build_predict_text(text, config):
    token = tokenizer(text)
    words_line = []
    seq_len = len(token)
    content = []
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))
    content.append((words_line, -1, seq_len))
    x = torch.LongTensor([_[0] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    y = torch.LongTensor([_[1] for _ in content]).to(
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))

    # pad前的长度(超过pad_size的设为pad_size)
    seq_len = torch.LongTensor([_[2] for _ in content])

    return (x, seq_len)


def build_predict_fasttext(text):
    lin = text.strip()
    words_line = []
    token = tokenizer(lin)
    seq_len = len(token)
    pad_size = config.pad_size
    if pad_size:
        if len(token) < pad_size:
            token.extend([PAD] * (pad_size - len(token)))
        else:
            token = token[:pad_size]
            seq_len = pad_size
    # word to id
    for word in token:
        words_line.append(vocab.get(word, vocab.get(UNK)))

    # fasttext ngram
    buckets = config.n_gram_vocab
    bigram = []
    trigram = []
    # ------ngram------
    for i in range(pad_size):
        bigram.append(biGramHash(words_line, i, buckets))
        trigram.append(triGramHash(words_line, i, buckets))
    words_line = torch.LongTensor([words_line]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    seq_len = torch.LongTensor([seq_len]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    bigram = torch.LongTensor([bigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    trigram = torch.LongTensor([trigram]).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    return words_line, seq_len, bigram, trigram


def predicts(texts_df, model, model_name, config):
    # global checkcnt
    # checkcnt += 1

    if 'Text' in texts_df.columns:
        texts = texts_df['Text'].tolist()
    elif 'Examples' in texts_df.columns:
        texts = texts_df['Examples'].tolist()
    else:
        raise ValueError("Columns不含Text或Examples" % (task_name))

    labels = []
    pros = []
    with torch.no_grad():
        for text in texts:
            # text = " ".join(jieba.lcut(text))
            text = clearTxt(text)
            if model_name == "FastText":
                data = build_predict_fasttext(text)
            else:
                data = build_predict_text(text, config)
            # print(data)
            model.eval()
            outputs = model(data)
            # predic = torch.max(outputs.data, 1)[1].cpu().numpy()
            list = outputs.cpu().numpy().tolist()
            if model_name == 'DPCNN' or model_name == 'TextRCNN':
                if list[0] > list[1]:
                    label = 0
                    pro = 1 - softmax(list)
                else:
                    label = 1
                    pro = softmax(list)
            else:
                if list[0][0] > list[0][1]:
                    label = 0
                    pro = 1 - softmax(list[0])
                else:
                    label = 1
                    pro = softmax(list[0])
            # label = predic
            labels.append(label)
            pros.append(pro)
            # print(label)
    assert len(texts) == len(labels) == len(pros), 'Bug in predict'

    res_dict = {'Label': labels, 'Confidence': pros, 'Text': texts}
    res_df = pd.DataFrame(res_dict)

    return res_df


parser = argparse.ArgumentParser(description='Configuration')
parser.add_argument('--model', default='TextCNN', type=str, required=True,
                    help='TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer')
parser.add_argument('--mode', default='all', type=str, help='all,morphology,phonetics,semantics,simple')
parser.add_argument('--word', default=False, type=bool, help='True for word, False for char')
parser.add_argument('--data', default=False, type=str, help='Original Text')

args = parser.parse_args()

if __name__ == '__main__':
    # model_name = 'TextCNN'  # 七选一：TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer
    # mode = 'all'  # 四选一：all,morphology,phonetics,semantics,simple

    model_name = args.model
    mode = args.mode
    original_data_file = args.data
    record_path = '/data/gzc/works/similarity_shop/Record_FinaRes.txt'

    base_text = pd.read_csv(original_data_file)
    res_df = pd.read_csv('/data/gzc/works/similarity_shop/result/%s__%s__FinalRes.csv' % (model_name, mode))

    dataset = 'Shopping10'
    embedding = 'embedding_weibo_word_c.npz'  # 词向量
    ################################################ 加载模型
    x = import_module('models.' + model_name)
    config = x.Config(dataset, embedding)
    np.random.seed(1)
    torch.manual_seed(1)
    torch.cuda.manual_seed_all(1)
    torch.backends.cudnn.deterministic = True
    vocab = pickle.load(open(config.vocab_path, 'rb'))
    model = x.Model(config).to(device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    model.load_state_dict(torch.load(dataset + '/model_saved/' + model_name + '.ckpt'))
    tokenizer = lambda x: x.split(' ')  # 以空格隔开，word-level

    ############################################## 有效生成率
    res_label = res_df["Result"].value_counts()
    success_rate = res_label['Succeed'] / res_label.sum()

    ############################################## 攻击前的acc
    pred_df_before = predicts(base_text, model, model_name, config)
    acc_before = comparison_getacc(base_text, pred_df_before)
    ############################################## 攻击后的acc
    for i in res_df.Text[res_df.Result == 'Succeed'].index:
        res_df.at[i, 'Text'] = res_df.at[i, 'Example']
    attack_df = res_df['Text'].to_frame()
    attack_df.to_csv('/data/gzc/works/similarity_shop/result/%s__%s__NewExample.csv' % (model_name, mode), index=False)
    pred_df = predicts(attack_df, model, model_name, config)
    #pred_df.to_csv('/data/gzc/works/similarity_shop/result/%s__%s__NewExample_res.csv' % (model_name, mode), index=False)
    acc_after = comparison_getacc(base_text, pred_df)

    ############################################## 平均扰动
    average_perturbation = res_df['Rate'].mean()

    print("########################## Success Rate , %s ##########################" % model_name)
    print("Success Rate: {}".format(round(success_rate, 4)))
    print("########################## Effectiveness , %s ##########################" % model_name)
    print("Predict-Accuracy-before:{}".format(round(acc_before, 4)))
    print("Predict-Accuracy-after: {}".format(round(acc_after, 4)))
    print("########################## Perturbation , %s ##########################" % model_name)
    print("Predict-Accuracy: {}".format(round(average_perturbation, 4)))

    with open(record_path, 'a') as f:
        out = '{}, {}, Success_rate_{}, Acc_before_{}, Acc_after_{}, Perturbation_{}'.format(model_name,
                                                                                                   mode,
                                                                                                   success_rate,
                                                                                                   acc_before,
                                                                                                   acc_after,
                                                                                                   average_perturbation)
        f.write(out + "\n")
