import synonyms


# synonyms包寻找同义词
def synonyms_zw(word, size):
    s = synonyms.nearby(word)
    if s[0] == []:
        return []
    candidates = []
    for i in range(1, size + 1):
        candidates.append(s[0][i])
    candidates = tuple(candidates)
    return candidates


# 词林寻找同义词
def get_sym(w, word_set):
    # w:  input word
    # word_set: 同义词词集或相关词词集
    results = []
    for each in word_set:
        for word in each:
            if w == word:
                results.append(each)
                break

    return results


def get_synonyms(w, sym_word):
    res = get_sym(w, sym_word)
    if len(res) == 1:
        return [x for x in res[0] if x != w]
    out = []
    for each in res:
        for word in each:
            if word != w:
                out.append(word)
    return out


def getsym():
    f = open('Basement/dictionary/cilin.txt', 'rb')
    lines = f.readlines()
    sym_words = []
    # 从txt中获取词条，构建同义词词集sym_words和相关词词集sym_class_words
    for line in lines:
        line = line.decode()
        line = line.replace('\r', '')
        line = line.replace('\n', '')
        items = line.split(' ')
        index = items[0]
        if (index[-1] == '='):
            sym_words.append(items[1:])
    return sym_words


def cilin_word_syn(word, size):
    sym_words = getsym()
    x = get_synonyms(word, sym_words)
    if word in x:
        x.remove(word)
    if len(x) < 1:
        return []
    if len(x) < size:
        candidates = [x[i] for i in range(len(x))]
    else:
        candidates = [x[i] for i in range(size)]
    candidates = tuple(candidates)
    return candidates


if __name__ == "__main__":
    word_list = ['家伙','你','大嫂']
    candidates = []

    for word in word_list:
        can = synonyms_zw(word, size=8)
        #can = cilin_word_syn(word, size=8)
        candidates.append(can)
    print(candidates)
