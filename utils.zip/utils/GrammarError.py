import pandas as pd
import language_tool_python

if __name__ == "__main__":
    tool = language_tool_python.LanguageTool('zh-CN')

    # 七选一：Bert、TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer
    model_name = 'Bert'
    # 四选一：all,morphology,phonetics,semantics,simple
    mode = 'simple'
    # 二选一：chn，shop
    dataset='shop'

    texts_df = pd.read_csv('/data/gzc/works/CH-Deceiver/my_result/attack performance/%s__%s__FinalRes.csv' % (dataset,model_name, mode))


    ##################Error of generated example
    examples = []
    for i in texts_df.Text[texts_df.Result == 'Succeed'].index:
        examples.append(texts_df.at[i, 'Example'])

    errors_num = 0
    for example in examples:
        errors_num = errors_num + len(tool.check(example))

    errors_avg = errors_num / len(examples)
    print('############### 模型{} ,mode={}, on {}2000, GrammerError={}'.format(model_name, mode, dataset,errors_avg))
