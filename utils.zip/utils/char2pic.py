import codecs, os, pygame, cv2

'''生成字符集
start,end = (0x4E00, 0x9FA5)  #汉字编码的范围
with codecs.open("char_all.txt", "wb", encoding="utf-8") as f:
    for codepoint in range(int(start),int(end)):
        f.write(chr(codepoint))  #写出汉字

# 同样可以，但速度稍慢 
pygame.init()
font = pygame.font.Font("msyh.ttf", 128) # 字体微软雅黑，大小128
for char in data:
    rtext = font.render(char, True, (0, 0, 0), (255, 255, 255))  # 字体黑色，背景白色
    pygame.image.save(rtext, os.path.join(picpath, char + ".png"))

    img1 = cv2.imread(os.path.join(picpath, char + ".png"))   
    img2 = cv2.copyMakeBorder(img1, 0, 0, 20, 21, cv2.BORDER_CONSTANT, value=(255, 255, 255))
    cv2.imwrite(os.path.join(picpath, char + ".png"), img2)
'''

os.environ["SDL_VIDEODRIVER"] = "dummy"

charfile = 'dictionary/char_allGB.txt'  # 取，文字
picpath = 'charpic_allGB1'  # 存，图片
ttffile = 'dictionary/msyh.ttf'  # 字体文件

# load char
with open(charfile, 'r') as f:
    data = f.read().replace('\n', '')
data = list(data)

# char2pic，169*169
if not os.path.exists(picpath):
    os.mkdir(picpath)

pygame.init()
font = pygame.font.Font(ttffile, 56)  # 字体微软雅黑，大小128
for char in data:
    win = pygame.display.set_mode((64, 64))  # 图像尺寸
    win.fill((255, 255, 255))
    rtext = font.render(char, True, (0, 0, 0), (255, 255, 255))  # 内容，是抗锯齿，字体黑色，背景白色
    text_rect = rtext.get_rect(center=(64 / 2, 64 / 2))
    win.blit(rtext, text_rect)  # 居中显示
    pygame.image.save(win, os.path.join(picpath, char + ".png"))
