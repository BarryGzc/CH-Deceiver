import numpy as np
import pandas as pd

import tensorflow as tf
from PIL import Image
import os, time, gc
from memory_profiler import profile
from guppy import hpy
from siamese import Siamese

os.environ['TF_CPP_MIN_LOG_LEVEL'] = "2"

gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)


@profile
def siamese_based(allchar_path, allpic_path):
    with open(allchar_path, 'r') as f:
        data = f.read().replace('\n', '')
    data = list(data)

    res_dict = {}

    for char in data:
        image1 = char + '.png'
        image_1 = Image.open(os.path.join(allpic_path, image1))

        model = Siamese()
        eachchar_time_start = time.time()

        simiarity_dict = {}
        for image2 in os.listdir(allpic_path):
            image_2 = Image.open(os.path.join(allpic_path, image2))
            probability = model.detect_image(image_1, image_2)
            if probability[0] > 0.5:  # 只保留相似度大于??的结果
                simiarity_dict[image2.rstrip('.png')] = probability[0]
        del model
        # gc.collect()
        # h2 = hpy()
        # print(h2.heap())
        if char in simiarity_dict:  # 去掉char自身
            simiarity_dict.pop(char)
        simiarity_list = sorted(simiarity_dict.items(), key=lambda x: x[1], reverse=True)
        simiarity_list = simiarity_list[0:4]  # 取前（4-1）个

        char_alternative = []
        for i in simiarity_list:
            char_alternative.append(i[0])

        eachchar_time_end = time.time()
        print('this char{} cost time:{}'.format(char,eachchar_time_end - eachchar_time_start))

        res_dict.update({char: char_alternative})

    res_df = pd.DataFrame.from_dict(res_dict, orient='index', columns=['Alt_1', 'Alt_2', 'Alt_3'])
    return res_df


if __name__ == "__main__":
    chars_file = './my_make_owndataset/char_allGB.txt'
    pics_dir = './data/char_GB'
    
    ##########################################################################################

    with open(chars_file, 'r') as f:
        data = f.read().replace('\n', '')
    data = list(data)

    res_dict = {}

    for char in data:
        image1 = char + '.png'
        image_1 = Image.open(os.path.join(pics_dir, image1))

        model = Siamese()
        eachchar_time_start = time.time()

        simiarity_dict = {}
        for image2 in os.listdir(pics_dir):
            image_2 = Image.open(os.path.join(pics_dir, image2))
            probability = model.detect_image(image_1, image_2)
            if probability[0] > 0.5:  # 只保留相似度大于??的结果
                simiarity_dict[image2.rstrip('.png')] = probability[0]
        del model
        # gc.collect()
        # h2 = hpy()
        # print(h2.heap())
        if char in simiarity_dict:  # 去掉char自身
            simiarity_dict.pop(char)
        simiarity_list = sorted(simiarity_dict.items(), key=lambda x: x[1], reverse=True)
        simiarity_list = simiarity_list[0:4]  # 取前（4-1）个

        char_alternative = []
        for i in simiarity_list:
            char_alternative.append(i[0])

        eachchar_time_end = time.time()
        print('this char{} cost time:{}'.format(char,eachchar_time_end - eachchar_time_start))

        res_dict.update({char: char_alternative})


    res_df = pd.DataFrame.from_dict(res_dict, orient='index')
    ##########################################################################################

    # time_start = time.time()
    # clock_start = time.clock()

   # result = siamese_based(chars_file, pics_dir)
    res_df.to_csv('./SiameseBased_corpus.csv', index_label='Text')
    # time_end = time.time()
    # clock_end = time.clock()
    # print('totally cost time:', time_end - time_start)
    # print('totally cost clock:', clock_end - clock_start)
