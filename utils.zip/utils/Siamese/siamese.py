import os

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from PIL import Image

from nets.siamese import siamese
from utils.utils import letterbox_image, preprocess_input, cvtColor, show_config


class Siamese(object):
    _defaults = {
        "model_path"        : 'data/my_weight.h5',

        "input_shape"       : [64, 64],

        "letterbox_image"   : False,
    }

    @classmethod
    def get_defaults(cls, n):
        if n in cls._defaults:
            return cls._defaults[n]
        else:
            return "Unrecognized attribute name '" + n + "'"


    def __init__(self, **kwargs):
        self.__dict__.update(self._defaults)
        for name, value in kwargs.items():
            setattr(self, name, value)

        self.generate()

        show_config(**self._defaults)
        

    def generate(self):
        model_path = os.path.expanduser(self.model_path)
        assert model_path.endswith('.h5'), 'Keras model or weights must be a .h5 file.'
        #---------------------------#
        #   载入模型与权值
        #---------------------------#
        self.model = siamese([self.input_shape[0], self.input_shape[1], 3])
        self.model.load_weights(self.model_path)
        print('{} model loaded.'.format(model_path))
        
    @tf.function
    def get_pred(self, photo):
        preds = self.model(photo, training=False)
        return preds

    def detect_image(self, image_1, image_2):

        image_1 = cvtColor(image_1)
        image_2 = cvtColor(image_2)

        image_1 = letterbox_image(image_1, [self.input_shape[1], self.input_shape[0]], self.letterbox_image)
        image_2 = letterbox_image(image_2, [self.input_shape[1], self.input_shape[0]], self.letterbox_image)

        photo1  = np.expand_dims(preprocess_input(np.array(image_1, np.float32)), 0)
        photo2  = np.expand_dims(preprocess_input(np.array(image_2, np.float32)), 0)

        output = np.array(self.get_pred([photo1, photo2])[0])

        return output
