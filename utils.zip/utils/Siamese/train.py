import datetime
import os
from functools import partial

import numpy as np
import tensorflow as tf
import tensorflow.keras.backend as K
from tensorflow.keras.callbacks import LearningRateScheduler, TensorBoard, EarlyStopping
from tensorflow.keras.optimizers import SGD, Adam

from nets.siamese import siamese
from utils.callbacks import LossHistory, ModelCheckpoint
from utils.dataloader import Datasets
from utils.utils import get_lr_scheduler, load_dataset, show_config
from utils.utils_fit import fit_one_epoch

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

if __name__ == "__main__":
    eager = False

    train_gpu = [0, ]

    dataset_path = "data/images"

    input_shape = [105, 105]

    train_own_data = True

    model_path = "data/init_weights.h5"


    Init_Epoch = 0
    Epoch = 100
    batch_size = 64

    Init_lr = 1e-2
    Min_lr = Init_lr * 0.01

    optimizer_type = "sgd"
    momentum = 0.9

    lr_decay_type = 'cos'

    save_period = 10

    save_dir = 'logs'

    num_workers = 1

    os.environ["CUDA_VISIBLE_DEVICES"] = ','.join(str(x) for x in train_gpu)
    ngpus_per_node = len(train_gpu)

    gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
    for gpu in gpus:
        tf.config.experimental.set_memory_growth(gpu, True)

    if ngpus_per_node > 1 and ngpus_per_node > len(gpus):
        raise ValueError("The number of GPUs specified for training is more than the GPUs on the machine")

    if ngpus_per_node > 1:
        strategy = tf.distribute.MirroredStrategy()
    else:
        strategy = None
    print('Number of devices: {}'.format(ngpus_per_node))

    if ngpus_per_node > 1:
        with strategy.scope():
            model = siamese(input_shape=[input_shape[0], input_shape[1], 3])
            if model_path != '':
                model.load_weights(model_path, by_name=True, skip_mismatch=True)
    else:
        model = siamese(input_shape=[input_shape[0], input_shape[1], 3])
        if model_path != '':
            model.load_weights(model_path, by_name=True, skip_mismatch=True)

    #   训练集和验证集的比例。
    train_ratio = 0.9
    train_lines, train_labels, val_lines, val_labels = load_dataset(dataset_path, train_own_data, train_ratio)
    num_train = len(train_lines)
    num_val = len(val_lines)

    show_config(
        model_path=model_path, input_shape=input_shape, \
        Init_Epoch=Init_Epoch, Epoch=Epoch, batch_size=batch_size, \
        Init_lr=Init_lr, Min_lr=Min_lr, optimizer_type=optimizer_type, momentum=momentum, lr_decay_type=lr_decay_type, \
        save_period=save_period, save_dir=save_dir, num_workers=num_workers, num_train=num_train, num_val=num_val
    )

    wanted_step = 3e4 if optimizer_type == "sgd" else 1e4
    total_step = num_train // batch_size * Epoch
    if total_step <= wanted_step:
        print(wanted_step, total_step, num_train, batch_size)
        print((num_train // batch_size))
        wanted_epoch = wanted_step // ((num_train // batch_size) + 1)
        print("\n\033[1;33;44m[Warning] 使用%s优化器时，建议将训练总步长设置到%d以上。\033[0m" % (optimizer_type, wanted_step))
        print("\033[1;33;44m[Warning] 本次运行的总训练数据量为%d，batch_size为%d，共训练%d个Epoch，计算出总训练步长为%d。\033[0m" % (
        num_train, batch_size, Epoch, total_step))
        print(
            "\033[1;33;44m[Warning] 由于总训练步长为%d，小于建议总步长%d，建议设置总世代为%d。\033[0m" % (total_step, wanted_step, wanted_epoch))

    #   训练分为两个阶段，两阶段初始的学习率不同，手动调节了学习率
    if True:

        nbs = 64
        lr_limit_max = 1e-3 if optimizer_type == 'adam' else 1e-1
        lr_limit_min = 3e-4 if optimizer_type == 'adam' else 5e-4
        Init_lr_fit = min(max(batch_size / nbs * Init_lr, lr_limit_min), lr_limit_max)
        Min_lr_fit = min(max(batch_size / nbs * Min_lr, lr_limit_min * 1e-2), lr_limit_max * 1e-2)

        optimizer = {
            'adam': Adam(lr=Init_lr_fit, beta_1=momentum),
            'sgd': SGD(lr=Init_lr_fit, momentum=momentum, nesterov=True)
        }[optimizer_type]

        lr_scheduler_func = get_lr_scheduler(lr_decay_type, Init_lr_fit, Min_lr_fit, Epoch)

        epoch_step = num_train // batch_size
        epoch_step_val = num_val // batch_size

        if epoch_step == 0 or epoch_step_val == 0:
            raise ValueError('数据集过小，无法进行训练，请扩充数据集。')

        train_dataset = Datasets(input_shape, train_lines, train_labels, batch_size, True)
        val_dataset = Datasets(input_shape, val_lines, val_labels, batch_size, False)

        if eager:
            gen = tf.data.Dataset.from_generator(partial(train_dataset.generate), (tf.float32, tf.float32, tf.float32))
            gen_val = tf.data.Dataset.from_generator(partial(val_dataset.generate),
                                                     (tf.float32, tf.float32, tf.float32))

            gen = gen.shuffle(buffer_size=batch_size).prefetch(buffer_size=batch_size)
            gen_val = gen_val.shuffle(buffer_size=batch_size).prefetch(buffer_size=batch_size)

            if ngpus_per_node > 1:
                gen = strategy.experimental_distribute_dataset(gen)
                gen_val = strategy.experimental_distribute_dataset(gen_val)

            time_str = datetime.datetime.strftime(datetime.datetime.now(), '%Y_%m_%d_%H_%M_%S')
            log_dir = os.path.join(save_dir, "loss_" + str(time_str))
            loss_history = LossHistory(log_dir)

            for epoch in range(Init_Epoch, Epoch):
                lr = lr_scheduler_func(epoch)
                K.set_value(optimizer.lr, lr)

                fit_one_epoch(model, loss_history, optimizer, epoch, epoch_step, epoch_step_val, gen, gen_val, Epoch,
                              save_period, save_dir, strategy)

                train_dataset.on_epoch_end()
                val_dataset.on_epoch_end()

        else:
            if ngpus_per_node > 1:
                with strategy.scope():
                    model.compile(loss="binary_crossentropy", optimizer=optimizer, metrics=["binary_accuracy"])
            else:
                model.compile(loss="binary_crossentropy", optimizer=optimizer, metrics=["binary_accuracy"])

            time_str = datetime.datetime.strftime(datetime.datetime.now(), '%Y_%m_%d_%H_%M_%S')
            log_dir = os.path.join(save_dir, "loss_" + str(time_str))
            logging = TensorBoard(log_dir)
            loss_history = LossHistory(log_dir)
            checkpoint = ModelCheckpoint(
                os.path.join(save_dir, "ep{epoch:03d}-loss{loss:.3f}-val_loss{val_loss:.3f}.h5"),
                monitor='val_loss', save_weights_only=True, save_best_only=False, period=save_period)
            checkpoint_last = ModelCheckpoint(os.path.join(save_dir, "last_epoch_weights.h5"),
                                              monitor='val_loss', save_weights_only=True, save_best_only=False,
                                              period=1)
            checkpoint_best = ModelCheckpoint(os.path.join(save_dir, "best_epoch_weights.h5"),
                                              monitor='val_loss', save_weights_only=True, save_best_only=True, period=1)
            early_stopping = EarlyStopping(monitor='val_loss', min_delta=0, patience=10, verbose=1)
            lr_scheduler = LearningRateScheduler(lr_scheduler_func, verbose=1)
            callbacks = [logging, loss_history, checkpoint, checkpoint_last, checkpoint_best, lr_scheduler]

            print('Train on {} samples, val on {} samples, with batch size {}.'.format(num_train, num_val, batch_size))
            model.fit(
                x=train_dataset,
                steps_per_epoch=epoch_step,
                validation_data=val_dataset,
                validation_steps=epoch_step_val,
                epochs=Epoch,
                initial_epoch=Init_Epoch,
                use_multiprocessing=True if num_workers > 1 else False,
                workers=num_workers,
                callbacks=callbacks
            )
