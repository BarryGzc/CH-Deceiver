# -*- coding: utf-8 -*-
import codecs, os, pygame
import cv2, shutil
from PIL import Image
import numpy as np



os.environ["SDL_VIDEODRIVER"] = "dummy"


def make_dataset(chars_file, ttfs_path, res_path):
    # load char
    with open(chars_file, 'r') as f:
        chars = f.read().replace('\n', '')
    chars = list(chars)

    # load result_dir
    if os.path.exists(res_path):
        shutil.rmtree(res_path)
        os.mkdir(res_path)
    else:
        os.mkdir(res_path)

    # load ttf
    ttf_list = []
    for file in os.listdir(ttfs_path):
        if file.endswith('.ttf'):
            ttf_list.append(file)

        # -----------------------------------------------------#
        #   生成图像尺寸分64*64，105*105
        #   64：font:56,win:64,text_rect:(64/2, 64/2)
        #  105：font:88,win:105,text_rect:(105/2, 105/2-5)
        # -----------------------------------------------------#
    pygame.init()
    for char in chars:
        picpath = os.path.join(res_path, char)
        if not os.path.exists(picpath):
            os.mkdir(picpath)
        for item in ttf_list:
            ttf = os.path.join(ttfs_path, item)
            font = pygame.font.Font(ttf, 88)  # 字体微软雅黑，大小88
            win = pygame.display.set_mode((105, 105))  # 图像尺寸
            win.fill((255, 255, 255))
            rtext = font.render(char, True, (0, 0, 0), (255, 255, 255))  # 内容，是抗锯齿，字体黑色，背景白色
            text_rect = rtext.get_rect(center=(105 / 2, 105 / 2 - 5))  # win图像尺寸的1/2，即居中
            win.blit(rtext, text_rect)  # 居中显示
            pygame.image.save(win, os.path.join(picpath, item.rstrip('.ttf') + ".png"))

    print('Dataset is ready')


def filter_invalid(res_path, record_path):
    ######### 清空record文件
    file = open(record_path, 'w').close()

    # time_start = time.clock()
    for root, dirs, files in os.walk(res_path):
        for char in files:
            img_path = os.path.join(root, char)
            img = Image.open(img_path)
            if np.min(img) == 255:
                os.remove(img_path)
                # print(img_path)
                with open(record_path, 'a') as f:
                    f.write(img_path.lstrip(res_path) + "\n")
    # time_end = time.clock()

    # print('总耗时:{}'.format(time_end - time_start))


def make_predict_data(chars_file, ttf_file, res_path):
    # load char
    with open(chars_file, 'r') as f:
        chars = f.read().replace('\n', '')
    chars = list(chars)

    # load result_dir
    pics_dir = res_path + '_' + ttf_file.rstrip('.ttf')
    if os.path.exists(pics_dir):
        shutil.rmtree(pics_dir)
        os.mkdir(pics_dir)
    else:
        os.mkdir(pics_dir)

    # char2pic，105*105
    pygame.init()
    font = pygame.font.Font(ttf_file, 88)  # 字体微软雅黑，大小56
    for char in chars:
        win = pygame.display.set_mode((105, 105))
        win.fill((255, 255, 255))
        rtext = font.render(char, True, (0, 0, 0), (255, 255, 255))  # 内容，是抗锯齿，字体黑色，背景白色
        text_rect = rtext.get_rect(center=(105 / 2, 105 / 2 - 5))  # 横(加左减右)，纵(加下减上)。
        win.blit(rtext, text_rect)  # 居中显示)
        pygame.image.save(win, os.path.join(pics_dir, char + ".png"))

    print('Predict_data is ready')


if __name__ == '__main__':
    chars_file = 'char_all.txt'
    res_dir = 'pics'

    ttfs_dir = 'ttfs_20'
    make_dataset(chars_file, ttfs_dir, res_dir)
    record_file = 'fileter_record.txt'
    filter_invalid(res_dir, record_file)

    ttf_file = 'msyh.ttf'
    make_predict_data(chars_file, ttf_file, res_dir)
