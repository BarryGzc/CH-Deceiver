# -*- coding=utf-8 -*-

import os, jieba
import numpy as np
from typing import Union
# import sys
# sys.path.append('/data/gzc/works/similarity_shop/utils/dictionary/')

from dictionary_loader import pinyin_phrase_loader, pinyin_char_loader, word_distribution_loader, read_file_by_line


class TrieTree(object):


    def __init__(self):
        self.dict_trie = dict()
        self.depth = 0

    def add_node(self, word, typing):
        word = word.strip()
        if word not in ['', '\t', ' ', '\r']:
            tree = self.dict_trie
            depth = len(word)
            word = word.lower()  # 将所有的字母全部转换成小写
            for char in word:
                if char in tree:
                    tree = tree[char]
                else:
                    tree[char] = dict()
                    tree = tree[char]
            if depth > self.depth:
                self.depth = depth
            if 'type' in tree and tree['type'] != typing:
                logging.warning(
                    '`{}` belongs to both `{}` and `{}`.'.format(
                        word, tree['type'], typing))
            else:
                tree['type'] = typing

    def build_trie_tree(self, dict_list, typing):
        for word in dict_list:
            self.add_node(word, typing)

    def search(self, word):

        tree = self.dict_trie
        res = None
        step = 0  # step 计数索引位置
        for char in word:
            if char in tree:
                tree = tree[char]
                step += 1
                if 'type' in tree:
                    res = (step, tree['type'])
            else:
                break
        if res:
            return res
        return 1, None


class Pinyin(object):

    def __init__(self):
        self.trie_tree_obj = None

    def _prepare(self):
        self.py_unk = '<py_unk>'
        self.py_unk_detail = {
            'consonant': '', 'vowel': '', 'tone': ''}

        consonants = 'bcdfghjklmnpqrstwxyz'
        consonants = list(consonants)
        self.consonants = ['zh', 'ch', 'sh', 'ng', 'hm', 'hng']
        self.consonants.extend(consonants)

        self.tones = '12345'

        self.pinyin_phrase = pinyin_phrase_loader()
        self.pinyin_char = pinyin_char_loader()

        # 加载 trie 树
        self.trie_tree_obj = TrieTree()
        self.trie_tree_obj.build_trie_tree(self.pinyin_phrase, 'phrase')
        self.trie_tree_obj.build_trie_tree(self.pinyin_char, 'char')

        # 格式转换
        self._pinyin_formater()

    @staticmethod
    def _pinyin_convert_standard_2_simple(standard_pinyin, letter_map_dict):
        suffix = '5'
        res = list()
        for letter in standard_pinyin:
            if letter in letter_map_dict:
                res.append(letter_map_dict[letter][0])
                if len(letter_map_dict[letter]) == 2:
                    suffix = letter_map_dict[letter][1]
            else:
                res.append(letter)

        res.append(suffix)
        return ''.join(res)

    def _get_consonant_vowel_tone(self, simple_pinyin):
        match_flag = False
        consonant = ''
        vowel = ''
        tone = ''
        for cur_consonant in self.consonants:
            if simple_pinyin.startswith(cur_consonant):
                consonant = cur_consonant
                break

        vowel_tone = simple_pinyin.replace(consonant, '', 1)

        for cur_tone in self.tones:
            if cur_tone in vowel_tone:
                tone = cur_tone
                break

        vowel = vowel_tone.replace(tone, '', 1)

        consonant_vowel_tone = {
            'consonant': consonant, 'vowel': vowel, 'tone': tone}
        return consonant_vowel_tone

    def _pinyin_formater(self):
        letter_map_dict = {
            'à': 'a4', 'á': 'a2', 'ā': 'a1', 'ǎ': 'a3',
            'ò': 'o4', 'ó': 'o2', 'ō': 'o1', 'ǒ': 'o3',
            'è': 'e4', 'é': 'e2', 'ē': 'e1', 'ě': 'e3',
            'ì': 'i4', 'í': 'i2', 'ī': 'i1', 'ǐ': 'i3',
            'ù': 'u4', 'ú': 'u2', 'ū': 'u1', 'ǔ': 'u3',
            'ǜ': 'v4', 'ǘ': 'v2', 'ǖ': 'v1', 'ǚ': 'v3',
            'ǹ': 'n4', 'ń': 'n2', 'ň': 'n3', 'ü': 'v',
            'ḿ': 'm2'}

        pinyin_list = list()
        for char, pinyin in self.pinyin_char.items():
            pinyin_list.extend(pinyin)
        for phrase, pinyin in self.pinyin_phrase.items():
            pinyin_list.extend(pinyin)
        pinyin_list = list(set(pinyin_list))

        self.pinyin_formater = dict()
        for standard_pinyin in pinyin_list:

            if standard_pinyin == self.py_unk:
                self.pinyin_formater.update(
                    {standard_pinyin: [standard_pinyin, self.py_unk_detail]})
            else:
                simple_pinyin = self._pinyin_convert_standard_2_simple(
                    standard_pinyin, letter_map_dict)

                consonant_vowel_tone = self._get_consonant_vowel_tone(
                    simple_pinyin)
                self.pinyin_formater.update(
                    {standard_pinyin: [simple_pinyin, consonant_vowel_tone]})

    def __call__(self, text: str,
                 formater: Union['standard', 'simple', 'detail'] = 'standard'):

        if self.trie_tree_obj is None:
            self._prepare()

        if formater not in ['standard', 'simple', 'detail']:
            raise ValueError(
                '`formater` should be either `standard` or `simple`.')

        record_list = list()  # 输出最终结果
        i = 0
        end = len(text)
        while i < end:
            pointer = text[i: self.trie_tree_obj.depth + i]  # 遇到标点符合暂停，有优化空间
            step, typing = self.trie_tree_obj.search(pointer)
            if typing == 'phrase':
                cur_pinyin = self.pinyin_phrase[pointer[0: step]]

                if formater == 'standard':
                    pass
                elif formater == 'simple':
                    cur_pinyin = [self.pinyin_formater[pinyin][0]
                                  for pinyin in cur_pinyin]
                elif formater == 'detail':
                    cur_pinyin = [self.pinyin_formater[pinyin][1]
                                  for pinyin in cur_pinyin]

                record_list.extend(cur_pinyin)
            elif typing == 'char':
                cur_pinyin = self.pinyin_char[pointer[0: step]][0]
                if formater == 'standard':
                    pass
                elif formater == 'simple':
                    cur_pinyin = self.pinyin_formater[cur_pinyin][0]
                elif formater == 'detail':
                    cur_pinyin = self.pinyin_formater[cur_pinyin][1]

                record_list.append(cur_pinyin)
            else:
                # print(step, typing, pointer[0])
                if formater == 'standard':
                    record_list.append(self.py_unk)
                elif formater == 'simple':
                    record_list.append(self.py_unk)
                elif formater == 'detail':
                    record_list.append(self.py_unk_detail)

            i += step

        assert len(record_list) == len(text)
        return record_list


class HomophoneSubstitution(object):

    def __init__(self):
        self.word_pinyin_dict = None

    def _prepare(self, seed=1):
        # self.jieba_obj = jieba
        # self.jieba_obj.initialize()

        self.random = np.random
        self.seed = seed
        if seed != 0:
            self.random.seed(seed)

        self.pinyin = Pinyin()
        self._construct_word_pinyin_dict()
        self.pinyin_mispronounce = {
            'zh': 'z', 'ch': 'c', 'sh': 's',
            'z': 'zh', 'c': 'ch', 's': 'sh',
            'l': 'n', 'n': 'l', 'f': 'h', 'h': 'f',
            'in': 'ing', 'an': 'ang', 'en': 'eng',
            'ing': 'in', 'ang': 'an', 'eng': 'en'}

    def _construct_word_pinyin_dict(self):
        word_dict = word_distribution_loader()
        word_pinyin_dict = dict()
        for word, info in word_dict.items():
            word_pinyin = self.pinyin(word, formater='detail')
            word_pinyin = ''.join([item['consonant'] + item['vowel']
                                   for item in word_pinyin])

            if word_pinyin in word_pinyin_dict:
                word_pinyin_dict[word_pinyin].update({word: info['total_num']})
            else:
                word_pinyin_dict.update({word_pinyin: {word: info['total_num']}})

        # 对于总频次过低，拼音对应词汇数量过少的，予以剔除。
        self.word_pinyin_dict = dict()
        for pinyin, word_dict in word_pinyin_dict.items():
            if len(word_dict) <= 1:  # 拼音对应词汇数量过少
                continue
            word_keys = [item[0] for item in word_dict.items()]
            word_values = [item[1] for item in word_dict.items()]
            total_num = sum(word_values)
            if total_num < 10000:  # 该拼音对应的词汇总频次过低，即非常见词，不予替换
                continue
            word_values = [val / total_num for val in word_values]
            self.word_pinyin_dict.update({pinyin: [word_keys, word_values]})

        del word_pinyin_dict

    def __call__(self, keywords_list, allow_mispronounce=True, seed=1):

        if self.word_pinyin_dict is None or self.seed != seed:
            self._prepare(seed=seed)

        segs = keywords_list
        pinyin_segs = [self.pinyin(seg, formater='detail') for seg in segs]

        augmented_text = self._augment_one(
            pinyin_segs, segs, allow_mispronounce=allow_mispronounce)

        return augmented_text

    def _augment_one(self, pinyin_segs, segs, allow_mispronounce=True):

        selected_segs = list()
        for pinyin_word, word in zip(pinyin_segs, segs):
            # 找到该词的拼音
            pinyin_list = list()
            for pinyin_char in pinyin_word:
                # if pinyin_char['consonant'] in self.pinyin_mispronounce:
                pinyin_list.append(pinyin_char['consonant'])
                pinyin_list.append(pinyin_char['vowel'])

            if not pinyin_list:  # 若无对应拼音则跳过
                selected_segs.append(word)
                continue

            if allow_mispronounce:
                # 找到该词的所有变音误读拼音
                # 仅支持单独一个字的变音，不允许多个字变音，造成过大的误差
                candidate_pinyin_list = [''.join(pinyin_list)]
                for idx, pinyin in enumerate(pinyin_list):
                    if pinyin in self.pinyin_mispronounce:
                        candidate_pinyin_list.append(
                            ''.join([pinyin if idx != i else self.pinyin_mispronounce[pinyin]
                                     for i, pinyin in enumerate(pinyin_list)]))

                # 确保原正确拼音的概率要大于变音误读的拼音
                # 进行两次随机选择，若第一次选择非原正确拼音，则再选一次
                selected_pinyin = self.random.choice(candidate_pinyin_list)
                if selected_pinyin != ''.join(pinyin_list):
                    selected_pinyin = self.random.choice(candidate_pinyin_list)

                if selected_pinyin in self.word_pinyin_dict:
                    selected_word = ''
                    for _ in range(10000):
                        selected_word = self.random.choice(
                            self.word_pinyin_dict[selected_pinyin][0],
                            p=self.word_pinyin_dict[selected_pinyin][1])
                        if selected_word != word:
                            break
                    if selected_word != word:
                        selected_segs.append(selected_word)
                    else:
                        for tmp_i, tmp_char in enumerate(word):
                            tmp_simbol = 0
                            tmp_char_pinyin = pinyin_list[2 * tmp_i:2 * (tmp_i + 1)]
                            tmp_char_pinyin = ''.join(tmp_char_pinyin)
                            for _ in range(len(self.word_pinyin_dict[tmp_char_pinyin][0])):
                                selected_char = self.random.choice(
                                    self.word_pinyin_dict[tmp_char_pinyin][0],
                                    p=self.word_pinyin_dict[tmp_char_pinyin][1])
                                if selected_char != tmp_char:
                                    selected_word = word.replace(tmp_char, selected_char, 1)
                                    tmp_simbol = 1
                                    break
                            if tmp_simbol == 1:
                                selected_segs.append(selected_word)
                                break
                        if tmp_simbol == 0:
                            selected_word = ''
                            selected_segs.append(selected_word)
                            '''
                            tmp_char_pinyins = self.word_pinyin_dict[tmp_char_pinyin][0]
                            tmp_char_pinyins_p = self.word_pinyin_dict[tmp_char_pinyin][1]
                            tmp_idx = tmp_char_pinyins.index(tmp_char)
                            del tmp_char_pinyins[tmp_idx]
                            del tmp_char_pinyins_p[tmp_idx]
                            selected_char = self.random.choice(tmp_char_pinyins, p=tmp_char_pinyins_p)
                            selected_word = word.replace(tmp_char, selected_char, 1)
                            break
                            '''
                else:
                    for tmp_i, tmp_char in enumerate(word):
                        tmp_simbol = 0
                        tmp_char_pinyin = pinyin_list[2 * tmp_i:2 * (tmp_i + 1)]
                        tmp_char_pinyin = ''.join(tmp_char_pinyin)
                        if tmp_char_pinyin not in self.word_pinyin_dict:
                            continue
                        else:
                            for _ in range(len(self.word_pinyin_dict[tmp_char_pinyin][0])):
                                selected_char = self.random.choice(
                                    self.word_pinyin_dict[tmp_char_pinyin][0],
                                    p=self.word_pinyin_dict[tmp_char_pinyin][1])
                                if selected_char != tmp_char:
                                    selected_word = word.replace(tmp_char, selected_char, 1)
                                    tmp_simbol = 1
                                    break
                            if tmp_simbol == 1:
                                selected_segs.append(selected_word)
                                break
                    if tmp_simbol == 0:
                        selected_word = ''
                        selected_segs.append(selected_word)
            else:
                selected_pinyin = ''.join(pinyin_list)
                if selected_pinyin in self.word_pinyin_dict:
                    selected_word = ''
                    for _ in range(len(self.word_pinyin_dict[selected_pinyin][0])):
                        selected_word = self.random.choice(
                            self.word_pinyin_dict[selected_pinyin][0],
                            p=self.word_pinyin_dict[selected_pinyin][1])
                        if selected_word != word:
                            break
                    selected_segs.append(selected_word)
                else:
                    selected_word = ''
                    selected_segs.append(selected_word)

        # return ''.join(selected_segs)
        return selected_segs


if __name__ == '__main__':


    pinyin = Pinyin()
    homophone_substitution = HomophoneSubstitution()

    keywords_list = ['一向', '积极', '我', '拥有', '手机', '问题', '你', '钱', '明天', '爱情', '跑步', '恋爱', '啊']

    homophone = homophone_substitution(keywords_list)
    print(homophone)

'''

    pinyin_all = []
    pinyin_initial = []
    for keyword in keywords_list:
        pinyin_all_tmp=pinyin(keyword)
        pinyin_all.append(''.join(pinyin_all_tmp))
        pinyin_initial.append(''.join([x[0] for x in pinyin_all_tmp]))
    print(pinyin_all)
    print(pinyin_initial)
'''
