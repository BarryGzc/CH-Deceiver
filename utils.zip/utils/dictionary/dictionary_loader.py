# -*- coding=utf-8 -*-
# library: jionlp

import os
import re
import math

#from jionlp import logging


DIR_PATH = os.path.dirname(os.path.abspath(__file__))
GRAND_DIR_PATH = os.path.dirname(DIR_PATH)


__all__ = ['char_distribution_loader', 'char_radical_loader',
           'china_location_change_loader', 'china_location_loader',
           'chinese_char_dictionary_loader',
           'chinese_idiom_loader', 'chinese_word_dictionary_loader',
           'idf_loader', 'negative_words_loader',
           'phone_location_loader',
           'pinyin_char_loader', 'pinyin_phrase_loader',
           'pornography_loader',
           'sentiment_expand_words_loader',
           'sentiment_words_loader', 'stopwords_loader',
           'telecom_operator_loader',
           'traditional_simplified_loader',
           'word_distribution_loader',
           'world_location_loader', 'xiehouyu_loader', 'STRUCTURE_DICT']

STRUCTURE_DICT = {
    0: '一体结构', 1: '左右结构', 2: '上下结构', 3: '左中右结构',
    4: '上中下结构', 5: '右上包围结构', 6: '左上包围结构', 7: '左下包围结构',
    8: '全包围结构', 9: '半包围结构'}


def read_file_by_line(file_path, line_num=None,
                      skip_empty_line=True, strip=True,
                      auto_loads_json=True):
    """ 读取一个文件的前 N 行，按列表返回，
    文件中按行组织，要求 utf-8 格式编码的自然语言文本。
    若每行元素为 json 格式可自动加载。

    Args:
        file_path(str): 文件路径
        line_num(int): 读取文件中的行数，若不指定则全部按行读出
        skip_empty_line(boolean): 是否跳过空行
        strip: 将每一行的内容字符串做 strip() 操作
        auto_loads_json(bool): 是否自动将每行使用 json 加载，默认是

    Returns:
        list: line_num 行的内容列表

    Examples:
        >>> file_path = '/path/to/stopwords.txt'
        >>> print(jio.read_file_by_line(file_path, line_num=3))

        # ['在', '然后', '还有']

    """
    content_list = list()
    count = 0
    with open(file_path, 'r', encoding='utf-8') as f:
        line = f.readline()
        while True:
            if line == '':  # 整行全空，说明到文件底
                break
            if line_num is not None:
                if count >= line_num:
                    break

            if line.strip() == '':
                if skip_empty_line:
                    count += 1
                    line = f.readline()
                else:
                    try:
                        if auto_loads_json:
                            cur_obj = json.loads(line.strip())
                            content_list.append(cur_obj)
                        else:
                            if strip:
                                content_list.append(line.strip())
                            else:
                                content_list.append(line)
                    except:
                        if strip:
                            content_list.append(line.strip())
                        else:
                            content_list.append(line)

                    count += 1
                    line = f.readline()
                    continue
            else:
                try:
                    if auto_loads_json:
                        cur_obj = json.loads(line.strip())
                        content_list.append(cur_obj)
                    else:
                        if strip:
                            content_list.append(line.strip())
                        else:
                            content_list.append(line)
                except:
                    if strip:
                        content_list.append(line.strip())
                    else:
                        content_list.append(line)

                count += 1
                line = f.readline()
                continue

    return content_list

def chinese_char_dictionary_loader():
    """ 加载百度汉语字典，字典与新华字典大同小异，分别包括：
    汉字，偏旁，字形结构，四角编码，笔画顺序，繁体字，五笔输入编码，拼音，释义

    本词典囊括了 utf-8 编码中，“一~龥”的所有汉字，但有所删减
    考虑到百度汉语字典无法与时俱进，其中有相当多的老旧内容，故增删说明如下：
        1、删除了所有的日本和字 -> 释义中包含 “日本汉字/日本地名用字” 内容，如 “桛 ā 1.日本和字。”；
        2、删除了释义未详的字 -> 释义中包含 “义未详” 内容，或某个字的某个读音义未详，如 “穝zuō## ⒈义未详。”
        3、删除了低频汉字 -> 释义中字频低于亿分之一的，且不在 char_distribution.json 中的字。
            如 “葨wēi 1.见"葨芝"。”
        4、删除了所有的韩国、朝鲜创字、用字、用意 -> 櫷guī槐木的一种（韩国汉字）
        5、删除了古代用字、用意 -> 释义中包含  “古同~/古代~/古通~/古书~/古地名/古人名” 内容，
            但如有多个释义，且其中有非古代释义，则保留该汉字；如 “鼃 wā 古同蛙”。但常见古字，如“巙kuí”

        共计删减 3402 字。

    """
    content = read_file_by_line(
        os.path.join(GRAND_DIR_PATH, 'dictionary',
                     'chinese_char_dictionary.txt'), strip=False)

    pinyin_ptn = re.compile('\[[a-zàáāǎòóōǒèéēěìíīǐùúūǔǜǘǖǚǹńňüḿ]{1,8}\]')
    explanation_ptn = re.compile('\d{1,2}\.')

    char_dict = dict()
    for idx, line in enumerate(content):
        segs = line.split('\t')

        assert len(segs) == 8

        # 拆解每个读音的各个含义
        pinyin_list = [item[1:-1] for item in pinyin_ptn.findall(segs[-1])]
        explanation_list = [item for item in pinyin_ptn.split(segs[-1].replace('~', segs[0]).strip())
                            if item != '']
        assert len(pinyin_list) == len(explanation_list)

        pinyin_explanation_dict = dict()
        for pinyin, explanations in zip(pinyin_list, explanation_list):
            explanations = [ex for ex in explanation_ptn.split(explanations) if ex != '']
            pinyin_explanation_dict.update({pinyin: explanations})

        char_dict.update({
            segs[0]: {'radical': segs[1],
                      'structure': STRUCTURE_DICT[int(segs[2])],
                      'corner_coding': segs[3],
                      'stroke_order': segs[4],
                      'traditional_version': segs[5],
                      'wubi_coding': segs[6],
                      'pinyin': pinyin_explanation_dict}})

    return char_dict


def char_radical_loader():
    """ 加载汉字字形词典 chinese_char_dictionary.txt ，字形内容包括
    偏旁部首、字形结构、四角编码、字形笔画与偏旁组成。"""

    char_dict = chinese_char_dictionary_loader()
    char_radical_dict = dict()
    for char, item in char_dict.items():
        radical = item['radical']
        structure = item['structure']
        # corner_coding = item['corner_coding']  # 四角编码
        stroke_order = item['stroke_order']  # 笔画顺序
        # wubi_coding = item['wubi_coding']  # 五笔打字编码

        char_radical_dict.update(
            {char: {'char': char,
                    'radical': radical,
                    'structure': structure,
                    'stroke_order': stroke_order}})

    return char_radical_dict


def pinyin_phrase_loader():
    content = read_file_by_line(os.path.join(
        GRAND_DIR_PATH, 'dictionary', 'pinyin_phrase.txt'))

    map_dict = dict()
    for item in content:
        key, value = item.split('\t')
        value = value.split('/')
        map_dict.update({key: value})

    return map_dict

def pinyin_char_loader():
    """加载拼音词典 chinese_char_dictionary.txt，以 list 返回，多音字也标出。"""

    char_dict = chinese_char_dictionary_loader()
    pinyin_char_dict = dict()
    for char, item in char_dict.items():
        pinyin_list = list(item['pinyin'].keys())
        pinyin_char_dict.update({char: pinyin_list})

    return pinyin_char_dict

def word_distribution_loader():
    """ 加载 jieba 分词后的词汇结果在中文文本中的词频分布，返回每个词在语料中的出现总次数、概率、
    概率的 -log10 值。

    Returns:
        dict(list): 例如
            {'国家': {'total_num': 101930,
                    'prob': 0.0014539722,
                    'log_prob': 3.2632870},
             ...}

    """
    word_info = read_file_by_line(
        os.path.join(GRAND_DIR_PATH, 'dictionary', 'word_distribution.json'))

    word_info_dict = dict()

    #total_num = sum([item[1] for item in word_info])

    for i, item in enumerate(word_info):
        x = str(re.findall('"([^"]*)"', item)[0])
        y = int(item.split(", ")[-1][:-1])
        word_info[i] = [x, y]

    total_num = sum([item[1] for item in word_info])


    for item in word_info:
        word_info_dict.update(
            {item[0]: {'total_num': item[1],
                       'prob': item[1] / total_num,
                       'log_prob': - math.log10(item[1] / total_num)}})

    return word_info_dict