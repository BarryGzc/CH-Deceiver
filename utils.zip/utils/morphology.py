#import codecs
#from typing import Union
import pandas as pd
import numpy as np

import sys,os, cv2

from dictionary.dictionary_loader import char_radical_loader, STRUCTURE_DICT
from skimage.metrics import structural_similarity as ssim


class CharRadical(object):


    def __init__(self):
        self.radicals = None

    def _prepare(self):
        self.radicals = char_radical_loader()
        self.cr_unk = '<cr_unk>'
        # self.corner_coding_unk = '00000'
        # self.wubi_coding_unk = 'XXXX'
        self.stroke_order_unk = '<so_unk>'

    def __call__(self, text: str):

        if self.radicals is None:
            self._prepare()

        record_list = list()  # 输出最终结果
        for char in text:
            radical = self.radicals.get(
                char, {'char': char,
                       'radical': self.cr_unk,
                       'structure': '一体结构',
                       'stroke_order': self.stroke_order_unk})
            record_list.append(radical)

        assert len(record_list) == len(text)
        return record_list

def getMatchNum(matches, ratio):
    matchesMask = [[0, 0] for i in range(len(matches))]
    matchNum = 0
    for i, (m, n) in enumerate(matches):
        if m.distance < ratio * n.distance:  # 将距离比率小于ratio的匹配点删选出来
            matchesMask[i] = [1, 0]
            matchNum += 1
    return (matchNum, matchesMask)


def getbest_sift(char, queryPath):
    for item in os.listdir(queryPath):
        if char + '.png' in item:
            char_filename = char + '.png'
            break
    try:
        samplePath = os.path.join(queryPath, char_filename)  # 样本图片
    except NameError:
        return 'NotFound this char'

    matchRatioList = []

    # 创建SIFT特征提取器
    sift = cv2.SIFT_create()
    # 创建FLANN匹配对象
    FLANN_INDEX_KDTREE = 0
    indexParams = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    searchParams = dict(checks=50)
    flann = cv2.FlannBasedMatcher(indexParams, searchParams)

    sampleImage = cv2.imread(samplePath, 0)
    sampleImage = cv2.resize(sampleImage, (128, 128))

    kp1, des1 = sift.detectAndCompute(sampleImage, None)  # 提取样本图片的特征
    for parent, dirnames, filenames in os.walk(queryPath):
        for pname in filenames:
            p = os.path.join(queryPath, pname)
            queryImage = cv2.imread(p, 0)
            queryImage = cv2.resize(queryImage, (128, 128))

            kp2, des2 = sift.detectAndCompute(queryImage, None)  # 提取比对图片的特征
            matches = flann.knnMatch(des1, des2, k=2)  # 匹配特征点，为了删选匹配点，指定k为2，这样对样本图的每个特征点，返回两个匹配
            (matchNum, matchesMask) = getMatchNum(matches, 0.9)  # 通过比率条件，计算出匹配程度
            matchRatio = matchNum * 1. / len(matches)
            if matchRatio > 0.5:  # 相似度阈值
                matchRatioList.append((pname.rstrip('.png'), matchRatio))

    matchRatioList.sort(key=lambda x: x[1], reverse=True)  # 按照匹配度排序

    return matchRatioList[:5]


def getbest_ssim(char1, path):
    for item in os.listdir(path):
        if char1 + '.png' in item:
            char1_filename = char1 + '.png'
            break
    try:
        image1 = cv2.imread(os.path.join(path, char1_filename))
    except NameError:
        return 'NotFound this char'

    image1 = cv2.cvtColor(image1, cv2.COLOR_BGR2GRAY)  # 将图像转换为灰度图
    res = []
    for item in os.listdir(path):
        image2 = cv2.imread(os.path.join(path, item))
        image2 = cv2.cvtColor(image2, cv2.COLOR_BGR2GRAY)  # 将图像转换为灰度图
        sim = ssim(image1, image2)
        if sim > 0.6:
            res.append((item.rstrip('.png'), sim))
    res.sort(key=lambda x: x[1], reverse=True)  # 按照匹配度排序

    return res[0:5]


def getbest_siamese(char1,num=4):
    corpus=pd.read_csv('dictionary/SiameseBased_corpus.csv',index_col=0)
    try:
        alts = corpus.loc[char1].tolist()  # most similar char
        while np.nan in alts:
            alts.remove(np.nan)
        if len(alts)==0:
            res=[char1]
        else:
            res=alts[0:num]
    except KeyError:
        res = [char1]  # no change，没有像的字

    return res[0]

if __name__ == '__main__':


    char='爱'
    res3 = getbest_siamese(char,4)
    print(res3)
