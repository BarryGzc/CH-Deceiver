# encoding:utf-8
import requests, json
import pandas as pd
from aip import AipNlp
import time

'''SDK调用，pip install baidu-aip
'''

if __name__ == "__main__":
    mode = 'all'
    ###################### Bert,TextCNN, TextRNN, TextRCNN, TextRNN_Att, DPCNN, Transformer, FastText
    model_name = 'Bert'
    input_df = pd.read_csv('../result/%s__%s__NewExample.csv' % (model_name, mode))
    ###   .drop([i for i in range(???)])

    APP_ID = '????'       ## ID
    API_KEY = '????'      ## API_KEY
    SECRET_KEY = '???'    ## SECRET_KEY
    client = AipNlp(APP_ID, API_KEY, SECRET_KEY)

    texts_before = []
    texts_after = []
    for i, text in enumerate(input_df['Text'].tolist()):
        time_start = time.time()
        corrected_text = client.ecnet(text).get('item').get('correct_query')

        texts_before.append(text)
        texts_after.append(corrected_text)
        res_df = pd.DataFrame({'Text_before': texts_before, "Text_after": texts_after})
        res_df.to_csv('../result_defense/%s__corrected_tmp.csv' % model_name, index=False)

        print("#### 第{}个，耗时{}, 修正后：{}".format(i + 1, round(time.time() - time_start, 4), corrected_text))

    print('### {} is correxcted, 共{}'.format(model_name, res_df.shape[0]))
